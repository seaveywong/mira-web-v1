/**
 * Mira 本地 API 执行器 v1.5 — Popup
 * 标签页: 状态 | 像素分享 | BM邀请 | 配置
 */

// ========== 工具 ==========

function $(id) { return document.getElementById(id); }
function $$(sel) { return document.querySelectorAll(sel); }

function send(message) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage(message, (res) => {
      if (chrome.runtime.lastError) { reject(new Error(chrome.runtime.lastError.message)); return; }
      if (!res || !res.ok) { reject(new Error((res && res.error) || "操作失败")); return; }
      resolve(res.data);
    });
  });
}

function graphApi(method, path, params) {
  return send({ type: "graphApiCall", method, path, params: params || {} });
}

function elapsed(ts) {
  if (!ts) return "--";
  const s = Math.round((Date.now() - new Date(ts).getTime()) / 1000);
  if (s < 60) return `${s}秒前`;
  if (s < 3600) return `${Math.round(s / 60)}分钟前`;
  return `${Math.round(s / 3600)}小时前`;
}

function remaining(ts) {
  if (!ts) return "--";
  const s = Math.round((new Date(ts).getTime() - Date.now()) / 1000);
  if (s <= 0) return "已过期";
  if (s < 3600) return `~${Math.round(s / 60)}分钟`;
  return `~${Math.round(s / 3600)}小时`;
}

function setMsg(el, text, cls) {
  el.innerHTML = text;
  el.className = "msg " + (cls || "info");
  el.style.display = text ? "block" : "none";
}

// ========== Tab 切换 ==========

function switchTab(name) {
  $$('.tab').forEach(t => t.classList.remove('active'));
  $$('.panel').forEach(p => p.classList.remove('active'));
  document.querySelector(`.tab[data-tab="${name}"]`).classList.add('active');
  $(`panel-${name}`).classList.add('active');
  if (name === 'status') loadStatus();
  if (name === 'config') loadConfig();
}

$$('.tab').forEach(tab => {
  tab.addEventListener('click', () => switchTab(tab.dataset.tab));
});

// ========== 状态面板 ==========

function renderToken(st) {
  const el = $("tokenContent");
  if (!st) { el.innerHTML = '<span style="color:#86868b">⏳ 等待首次自动提取...</span>'; return; }
  const ts = st.tokenStatus || {};
  if (!ts.valid && !ts.tokenMask) {
    el.innerHTML = `
      <div class="kv"><span class="k">状态</span><span class="v red">❌ 无 Token</span></div>
      <div class="kv"><span class="k">说明</span><span class="v gray">${ts.error || '插件每55分钟自动静默提取'}</span></div>`;
    return;
  }
  const perms = ts.permissions || [];
  const permTags = perms.slice(0,5).map(p => `<span class="badge b">${p}</span>`).join('');
  let h = '';
  h += `<div class="kv"><span class="k">状态</span><span class="v ${ts.valid !== false ? 'green' : 'red'}">${ts.valid !== false ? '✅ 有效' : '❌ 失效'}</span></div>`;
  h += `<div class="kv"><span class="k">Token</span><span class="v blue">${ts.tokenMask || '****'}</span></div>`;
  if (ts.fbName) h += `<div class="kv"><span class="k">用户</span><span class="v">${ts.fbName} <span class="gray">ID:${ts.fbId || '--'}</span></span></div>`;
  if (ts.c_user && !ts.fbName) h += `<div class="kv"><span class="k">用户 ID</span><span class="v">${ts.c_user}</span></div>`;
  if (ts.source) h += `<div class="kv"><span class="k">来源</span><span class="v gray">${ts.source}</span></div>`;
  if (ts.extractedAt) h += `<div class="kv"><span class="k">提取时间</span><span class="v">${elapsed(ts.extractedAt)}</span></div>`;
  if (ts.expiresAt) {
    const rem = remaining(ts.expiresAt);
    h += `<div class="kv"><span class="k">过期</span><span class="v ${rem === '已过期' ? 'red' : 'green'}">${rem}</span></div>`;
  }
  if (permTags) h += `<div style="margin-top:3px">${permTags}</div>`;
  if (ts.hasAdsMgmt) h += `<span class="badge g">ads_management</span>`;
  if (ts.hasBizMgmt) h += `<span class="badge b">business_management</span>`;
  if (ts.error) h += `<div class="kv"><span class="k">错误</span><span class="v red">${ts.error}</span></div>`;
  el.innerHTML = h;
}

function renderMira(s) {
  const el = $("miraContent");
  if (!s || !s.nodeId) {
    el.innerHTML = '<span style="color:#86868b">未绑定 Mira。切换到"⚙️ 配置"标签页输入绑定码激活。</span>';
    return;
  }
  const last = s.lastStatus || {};
  const node = last.node || {};
  let h = '';
  h += `<div class="kv"><span class="k">执行器</span><span class="v">${s.nodeName || s.nodeId}</span></div>`;
  h += `<div class="kv"><span class="k">心跳</span><span class="v ${last.ok !== false ? 'green' : 'red'}">${elapsed(last.updatedAt ? new Date(last.updatedAt).toISOString() : null)} ${last.ok !== false ? '✅' : '❌'}</span></div>`;
  if (last.message) h += `<div class="kv"><span class="k">消息</span><span class="v gray">${last.message}</span></div>`;
  if (node.fb_user_name) h += `<div class="kv"><span class="k">FB 用户</span><span class="v">${node.fb_user_name}</span></div>`;
  if (node.account_count !== undefined) h += `<span class="badge b">${node.account_count} 个广告账户</span>`;
  if (node.has_ads_management) h += `<span class="badge g">ads_manage</span>`;
  if (node.last_error) h += `<div class="kv"><span class="k">说明</span><span class="v red">${node.last_error}</span></div>`;
  el.innerHTML = h;
}

async function loadStatus() {
  try {
    const data = await send({ type: "getFullStatus" });
    const s = data.settings || data;
    renderToken(data);
    renderMira(s);
    const ts = data.tokenStatus || {};
    const ms = s.lastStatus || {};
    const allOk = ts.valid !== false && ms.ok !== false;
    $("sysDot").className = "dot " + (allOk ? "ok" : ts.valid === false ? "err" : "warn");
  } catch (e) { /* 下次刷新重试 */ }
}

// ========== 像素分享面板 ==========

const pixelState = { bmList: [], selBmId: null, pixelList: [], selPixelId: null };

async function loadBMs() {
  const listEl = $("bmList");
  const hintEl = $("bmHint");
  listEl.innerHTML = '<span style="color:#86868b">⏳ 加载中...</span>';
  try {
    const data = await graphApi("GET", "me/businesses", { fields: "id,name,primary_page", limit: 200 });
    pixelState.bmList = data.data || [];
    if (pixelState.bmList.length === 0) {
      listEl.innerHTML = '<span style="color:#86868b">未找到 BM，请确认 Token 有 business_management 权限</span>';
      return;
    }
    hintEl.textContent = `找到 ${pixelState.bmList.length} 个 BM`;
    renderBmList();
  } catch (err) {
    listEl.innerHTML = `<span style="color:#991b1b">❌ ${err.message}</span>`;
  }
}

function renderBmList() {
  const listEl = $("bmList");
  listEl.innerHTML = pixelState.bmList.map((bm, i) => `
    <div class="select-item ${pixelState.selBmId === bm.id ? 'sel' : ''}" data-id="${bm.id}">
      <span>${i+1}. ${bm.name} <span class="id">(${bm.id})</span></span>
      <span style="font-size:9px">→</span>
    </div>
  `).join('');
  listEl.querySelectorAll('.select-item').forEach(item => {
    item.addEventListener('click', () => {
      pixelState.selBmId = item.dataset.id;
      pixelState.selPixelId = null;
      renderBmList();
      $("pixelStep2").style.display = "block";
      $("pxDiv1").style.display = "block";
      $("pixelStep3").style.display = "none";
      $("pxDiv2").style.display = "none";
      $("pixelList").innerHTML = '<span style="color:#86868b">点击"加载像素列表"</span>';
      $("pixelResult").innerHTML = '';
    });
  });
}

async function loadPixels() {
  if (!pixelState.selBmId) return;
  const listEl = $("pixelList");
  const hintEl = $("pixelHint");
  listEl.innerHTML = '<span style="color:#86868b">⏳ 加载中...</span>';
  try {
    const data = await graphApi("GET", `${pixelState.selBmId}/owned_pixels`, {
      fields: "id,name,code,creation_time,last_fired_time",
      limit: 200
    });
    pixelState.pixelList = data.data || [];
    if (pixelState.pixelList.length === 0) {
      listEl.innerHTML = '<span style="color:#86868b">该 BM 下没有像素</span>';
      return;
    }
    hintEl.textContent = `找到 ${pixelState.pixelList.length} 个像素`;
    renderPixelList();
  } catch (err) {
    listEl.innerHTML = `<span style="color:#991b1b">❌ ${err.message}</span>`;
  }
}

function renderPixelList() {
  const listEl = $("pixelList");
  listEl.innerHTML = pixelState.pixelList.map((px, i) => `
    <div class="select-item ${pixelState.selPixelId === px.id ? 'sel' : ''}" data-id="${px.id}">
      <span>${i+1}. ${px.name} <span class="id">(${px.id})</span></span>
      <span style="font-size:9px">→</span>
    </div>
  `).join('');
  listEl.querySelectorAll('.select-item').forEach(item => {
    item.addEventListener('click', () => {
      pixelState.selPixelId = item.dataset.id;
      renderPixelList();
      $("pixelStep3").style.display = "block";
      $("pxDiv2").style.display = "block";
      $("pixelResult").innerHTML = '';
    });
  });
}

async function sharePixel() {
  const partnerBmId = $("partnerBmId").value.trim();
  if (!partnerBmId) { setMsg($("pixelResult"), "请输入合作伙伴 BM ID", "err"); return; }
  if (!pixelState.selPixelId) { setMsg($("pixelResult"), "请先选择要分享的像素", "err"); return; }

  const resEl = $("pixelResult");
  setMsg(resEl, "⏳ 正在分享...", "info");
  try {
    const selPx = pixelState.pixelList.find(p => p.id === pixelState.selPixelId);
    const selBm = pixelState.bmList.find(b => b.id === pixelState.selBmId);
    const result = await graphApi("POST", `${pixelState.selPixelId}/shared_agencies`, {
      business: partnerBmId
    });
    setMsg(resEl, `🎉 像素分享成功！<br>像素: ${selPx?.name || pixelState.selPixelId}<br>来源 BM: ${selBm?.name || pixelState.selBmId}<br>目标 BM: ${partnerBmId}`, "ok");
  } catch (err) {
    let hint = err.message || String(err);
    if (hint.includes("permission")) hint += "<br>💡 请确认 Token 有 business_management 权限";
    else if (hint.includes("already")) hint += "<br>💡 该像素可能已分享给此 BM";
    setMsg(resEl, `❌ 分享失败: ${hint}`, "err");
  }
}

// ========== BM 邀请面板 ==========

const inviteState = { bmList: [], selBmId: null };

async function loadBMsForInvite() {
  const listEl = $("inviteBmList");
  const hintEl = $("inviteBmHint");
  listEl.innerHTML = '<span style="color:#86868b">⏳ 加载中...</span>';
  try {
    const data = await graphApi("GET", "me/businesses", { fields: "id,name", limit: 200 });
    inviteState.bmList = data.data || [];
    if (inviteState.bmList.length === 0) {
      listEl.innerHTML = '<span style="color:#86868b">未找到 BM</span>';
      return;
    }
    hintEl.textContent = `找到 ${inviteState.bmList.length} 个 BM`;
    renderInviteBmList();
  } catch (err) {
    listEl.innerHTML = `<span style="color:#991b1b">❌ ${err.message}</span>`;
  }
}

function renderInviteBmList() {
  const listEl = $("inviteBmList");
  listEl.innerHTML = inviteState.bmList.map((bm, i) => `
    <div class="select-item ${inviteState.selBmId === bm.id ? 'sel' : ''}" data-id="${bm.id}">
      <span>${i+1}. ${bm.name} <span class="id">(${bm.id})</span></span>
      <span style="font-size:9px">→</span>
    </div>
  `).join('');
  listEl.querySelectorAll('.select-item').forEach(item => {
    item.addEventListener('click', () => {
      inviteState.selBmId = item.dataset.id;
      renderInviteBmList();
      $("inviteResult").innerHTML = '';
    });
  });
}

async function inviteUser() {
  if (!inviteState.selBmId) { setMsg($("inviteResult"), "请先选择一个 BM", "err"); return; }
  const email = $("inviteEmail").value.trim();
  if (!email || !email.includes("@")) { setMsg($("inviteResult"), "请输入有效的邮箱地址", "err"); return; }
  const role = $("inviteRole").value;

  const resEl = $("inviteResult");
  const selBm = inviteState.bmList.find(b => b.id === inviteState.selBmId);
  setMsg(resEl, "⏳ 正在发送邀请...", "info");
  try {
    await graphApi("POST", `${inviteState.selBmId}/users`, { email, role });
    setMsg(resEl, `🎉 邀请已发送！<br>用户: ${email}<br>BM: ${selBm?.name || inviteState.selBmId}<br>角色: ${role}`, "ok");
    $("inviteEmail").value = "";
  } catch (err) {
    let hint = err.message || String(err);
    if (hint.includes("already") || hint.includes("invited")) hint += "<br>💡 该用户可能已被邀请";
    else if (hint.includes("permission")) hint += "<br>💡 Token 需要 business_management 权限";
    setMsg(resEl, `❌ 邀请失败: ${hint}`, "err");
  }
}

// ========== 配置面板 ==========

async function loadConfig() {
  try {
    const s = await send({ type: "getSettings" });
    $("cfgServerUrl").value = s.serverUrl || "";
    $("cfgNodeName").value = s.nodeName || "";
    $("cfgAccessToken").value = s.accessToken || "";
    $("cfgExpiresMin").value = s.expiresInMinutes || "";
  } catch (e) { /* ignore */ }
}

// ========== 全局按钮 ==========

$("btnRefresh").addEventListener("click", async () => {
  const btn = $("btnRefresh");
  const old = btn.textContent;
  btn.disabled = true;
  btn.textContent = "⏳ 提取中...";
  try {
    const data = await send({ type: "silentRefresh" });
    btn.textContent = data.success ? "✅ 已刷新" : "❌ 失败";
  } catch (err) {
    btn.textContent = "❌ " + (err.message || "失败").slice(0, 10);
  }
  setTimeout(() => { btn.textContent = old; btn.disabled = false; }, 2000);
  await loadStatus();
});

$("btnHeartbeat").addEventListener("click", async () => {
  const btn = $("btnHeartbeat");
  btn.disabled = true; btn.textContent = "⏳...";
  try {
    await send({ type: "heartbeat" });
    btn.textContent = "✅ 成功";
  } catch (err) {
    btn.textContent = "❌ 失败";
  }
  setTimeout(() => { btn.textContent = "✅ 心跳验证"; btn.disabled = false; }, 1500);
  await loadStatus();
});

// 像素分享按钮
$("btnLoadBMs").addEventListener("click", loadBMs);
$("btnLoadPixels").addEventListener("click", loadPixels);
$("btnSharePixel").addEventListener("click", sharePixel);

// BM 邀请按钮
$("btnLoadBMsForInvite").addEventListener("click", loadBMsForInvite);
$("btnInviteUser").addEventListener("click", inviteUser);

// 配置按钮
$("btnSave").addEventListener("click", async () => {
  const btn = $("btnSave");
  btn.disabled = true; btn.textContent = "保存中...";
  try {
    await send({
      type: "saveSettings",
      serverUrl: $("cfgServerUrl").value.trim(),
      nodeName: $("cfgNodeName").value.trim(),
      accessToken: $("cfgAccessToken").value.trim(),
      expiresInMinutes: $("cfgExpiresMin").value.trim()
    });
    btn.textContent = "✅ 已保存";
  } catch (err) {
    btn.textContent = "❌";
  }
  setTimeout(() => { btn.textContent = "保存配置"; btn.disabled = false; }, 1500);
  await loadStatus();
});

$("btnRegister").addEventListener("click", async () => {
  const btn = $("btnRegister");
  btn.disabled = true; btn.textContent = "激活中...";
  try {
    await send({
      type: "register",
      serverUrl: $("cfgServerUrl").value.trim(),
      nodeName: $("cfgNodeName").value.trim(),
      code: $("cfgBindCode").value.trim()
    });
    btn.textContent = "✅ 已激活";
    $("cfgBindCode").value = "";
  } catch (err) {
    btn.textContent = "❌ " + (err.message || "").slice(0, 10);
  }
  setTimeout(() => { btn.textContent = "激活执行器"; btn.disabled = false; }, 2000);
  await loadStatus();
});

$("btnClearToken").addEventListener("click", async () => {
  $("cfgAccessToken").value = "";
  $("cfgExpiresMin").value = "";
  await send({ type: "clearToken" });
  await loadStatus();
});

// ========== 定时刷新 ==========

async function autoRefresh() {
  // 仅刷新当前活动标签页
  const activeTab = document.querySelector('.tab.active');
  if (activeTab && activeTab.dataset.tab === 'status') {
    await loadStatus().catch(() => {});
  }
  setTimeout(autoRefresh, 5000);
}

// ========== 启动 ==========

loadStatus();
autoRefresh();
