# FB BM Toolkit - 广告创建测试
# 通过浏览器 Bridge 执行 Facebook Marketing API
#
# 用法:
#   .\test-create-ad.ps1                     # 自动发现 ad accounts
#   .\test-create-ad.ps1 -ActId "123456"     # 指定 ad account 创建测试广告
#   .\test-create-ad.ps1 -SkipCreate         # 仅查询，不创建

param(
    [string]$ActId = "",           # Facebook Ad Account ID (act_XXXXX)
    [switch]$SkipCreate,           # 只查询不创建
    [string]$PageId = "",          # Facebook Page ID
    [string]$BridgeUrl = "http://127.0.0.1:9876"
)

$ErrorActionPreference = "Continue"

# 加载共享辅助函数
. "$PSScriptRoot\bridge-helpers.ps1"

# ========== Step 1: 验证 Token ==========

Write-Host @"

╔══════════════════════════════════════════════════╗
║   FB BM Toolkit - 广告创建测试                   ║
║   验证: 浏览器 EAA token 能否创建广告?            ║
╚══════════════════════════════════════════════════╝
"@ -ForegroundColor White

# 1a. 获取 token
Write-Host "`n========== Step 1: 获取 Token ==========" -ForegroundColor Yellow
try {
    $tokenData = Invoke-RestMethod -Uri "$BridgeUrl/token" -Method GET -TimeoutSec 5
    Write-Host "✅ Token 已获取" -ForegroundColor Green
    Write-Host "   EAA: $($tokenData.eaa_token.Substring(0, [Math]::Min(30, $tokenData.eaa_token.Length)))..."
    Write-Host "   c_user: $($tokenData.c_user)"
    Write-Host "   年龄: $($tokenData.age_seconds)s"
} catch {
    Write-Host "❌ 无法获取 Token! Bridge Server 是否在运行?" -ForegroundColor Red
    Write-Host "   先启动: fb-bm-toolkit\server\start.bat"
    exit 1
}

# 1b. 验证 token 有效性
Write-Host "`n验证 Token 有效性..."
$me = Invoke-BridgeApi -Method GET -Url "https://graph.facebook.com/v18.0/me?fields=id,name,email"
if ($me.Success) {
    Write-Host "   👤 用户: $($me.Data.name) (ID: $($me.Data.id))" -ForegroundColor Green
} else {
    Write-Host "   ❌ Token 无效!" -ForegroundColor Red
    exit 1
}

# ========== Step 2: 获取 Ad Accounts ==========

Write-Host "`n========== Step 2: 获取广告账户 ==========" -ForegroundColor Yellow

$accounts = Invoke-BridgeApi -Method GET `
    -Url "https://graph.facebook.com/v18.0/me/adaccounts?fields=id,name,account_status,currency,amount_spent"

$adAccounts = @()
if ($accounts.Success -and $accounts.Data.data) {
    $adAccounts = $accounts.Data.data
    Write-Host "✅ 找到 $($adAccounts.Count) 个广告账户:" -ForegroundColor Green
    $i = 0
    foreach ($acc in $adAccounts) {
        $i++
        $status = if ($acc.account_status -eq 1) { "✅ 活跃" } else { "⚠️ $($acc.account_status)" }
        Write-Host "   $i. act_$($acc.id) | $($acc.name) | $status | $($acc.currency)"
    }
} else {
    Write-Host "❌ 无法获取广告账户! 完整响应:" -ForegroundColor Red
    Write-Host ($accounts | ConvertTo-Json -Depth 3)
    Write-Host ""
    Write-Host "可能原因:" -ForegroundColor Yellow
    Write-Host "  1. 浏览器 EAA token 无法访问 Marketing API (需要开发者 App token)"
    Write-Host "  2. 当前用户没有广告账户"
    Write-Host "  3. Token 权限不足"
    exit 1
}

# ========== Step 3: 选广告账户 ==========

if (-not $ActId) {
    if ($adAccounts.Count -eq 1) {
        $ActId = "act_$($adAccounts[0].id)"
        Write-Host "`n自动选择唯一账户: $ActId"
    } else {
        $ActId = "act_$($adAccounts[0].id)"
        Write-Host "`n多个账户, 默认选择第1个: $ActId (用 -ActId 参数指定)"
    }
}

# ========== Step 4: 获取 Pages ==========

Write-Host "`n========== Step 3: 获取主页 ==========" -ForegroundColor Yellow

$pages = Invoke-BridgeApi -Method GET `
    -Url "https://graph.facebook.com/v18.0/me/accounts?fields=id,name,access_token"

$fbPages = @()
if ($pages.Success -and $pages.Data.data) {
    $fbPages = $pages.Data.data
    Write-Host "✅ 找到 $($fbPages.Count) 个主页:" -ForegroundColor Green
    foreach ($p in $fbPages) {
        Write-Host "   $($p.id) | $($p.name)"
    }
    if (-not $PageId -and $fbPages.Count -gt 0) {
        $PageId = $fbPages[0].id
        Write-Host "自动选择: $($fbPages[0].name) (ID: $PageId)"
    }
} else {
    Write-Host "⚠️ 无法获取主页 (创建流量广告需要主页)" -ForegroundColor Yellow
    Write-Host ($pages | ConvertTo-Json -Depth 3)
}

# ========== Step 5: 创建广告 (或不创建) ==========

if ($SkipCreate) {
    Write-Host "`n========== 跳过创建 (--SkipCreate) ==========" -ForegroundColor Yellow
    Write-Host "`n✅ 验证结论:" -ForegroundColor Green
    Write-Host "  • Token 有效: ✅"
    Write-Host "  • 可获取广告账户: ✅"
    Write-Host "  • 可获取主页: $(if ($fbPages.Count -gt 0) {'✅'} else {'⚠️'})"
    Write-Host "  • 创建广告: ⏭️ 跳过 (去掉 -SkipCreate 参数测试)"
    exit 0
}

if (-not $PageId) {
    Write-Host "`n⚠️ 没有主页，无法创建流量广告" -ForegroundColor Red
    Write-Host "需要先创建一个 Facebook Page: https://www.facebook.com/pages/create"
    exit 1
}

Write-Host "`n========== Step 4: 创建测试广告 ==========" -ForegroundColor Yellow

$campaignName = "测试广告_浏览器Token_" + (Get-Date -Format "MMdd_HHmm")

# 先创建 Campaign
Write-Host "`n--- 创建 Campaign ---" -ForegroundColor Cyan
$campaignBody = @{
    name                    = $campaignName
    objective               = "OUTCOME_TRAFFIC"
    status                  = "PAUSED"
    special_ad_categories   = @()
}

$campaign = Invoke-BridgeApi -Method POST `
    -Url "https://graph.facebook.com/v18.0/$ActId/campaigns" `
    -Body $campaignBody

if (-not $campaign.Success) {
    Write-Host "`n❌ Campaign 创建失败!" -ForegroundColor Red
    Write-Host "这可能证明: 浏览器 EAA token 不能调用 Marketing API"
    Write-Host "需要改用 Facebook 内部 API (GraphQL/AJAX endpoint)"
    exit 1
}

$campaignId = $campaign.Data.id
Write-Host "✅ Campaign 创建成功: $campaignId" -ForegroundColor Green

# 创建 Ad Set
Write-Host "`n--- 创建 Ad Set ---" -ForegroundColor Cyan
$adSetBody = @{
    name               = "AdSet_$campaignName"
    campaign_id        = $campaignId
    billing_event      = "IMPRESSIONS"
    optimization_goal  = "REACH"
    daily_budget       = 500   # $5/day (in cents for USD)
    targeting          = @{
        geo_locations  = @{ countries = @("US") }
        age_min        = 18
        age_max        = 65
    }
    start_time         = (Get-Date).AddHours(1).ToString("yyyy-MM-ddTHH:mm:sszzz")
    status             = "PAUSED"
}

$adSet = Invoke-BridgeApi -Method POST `
    -Url "https://graph.facebook.com/v18.0/$ActId/adsets" `
    -Body $adSetBody

if (-not $adSet.Success) {
    Write-Host "❌ Ad Set 创建失败!" -ForegroundColor Red
    # 清理 Campaign
    Write-Host "清理: 删除 Campaign $campaignId..."
    Invoke-BridgeApi -Method DELETE -Url "https://graph.facebook.com/v18.0/$campaignId" | Out-Null
    exit 1
}

$adSetId = $adSet.Data.id
Write-Host "✅ Ad Set 创建成功: $adSetId" -ForegroundColor Green

# 创建 Ad Creative
Write-Host "`n--- 创建 Ad Creative ---" -ForegroundColor Cyan
$creativeBody = @{
    name       = "Creative_$campaignName"
    object_story_spec = @{
        page_id = $PageId
        link_data = @{
            link        = "https://www.facebook.com/$PageId"
            message     = "测试广告文案 - 浏览器Token方式"
            name        = "测试标题"
            description = "测试描述"
        }
    }
}

$creative = Invoke-BridgeApi -Method POST `
    -Url "https://graph.facebook.com/v18.0/$ActId/adcreatives" `
    -Body $creativeBody

if (-not $creative.Success) {
    Write-Host "❌ Creative 创建失败!" -ForegroundColor Red
    # 清理
    Invoke-BridgeApi -Method DELETE -Url "https://graph.facebook.com/v18.0/$adSetId" | Out-Null
    Invoke-BridgeApi -Method DELETE -Url "https://graph.facebook.com/v18.0/$campaignId" | Out-Null
    exit 1
}

$creativeId = $creative.Data.id
Write-Host "✅ Creative 创建成功: $creativeId" -ForegroundColor Green

# 创建 Ad
Write-Host "`n--- 创建 Ad ---" -ForegroundColor Cyan
$adBody = @{
    name        = "Ad_$campaignName"
    adset_id    = $adSetId
    creative    = @{ creative_id = $creativeId }
    status      = "PAUSED"
}

$ad = Invoke-BridgeApi -Method POST `
    -Url "https://graph.facebook.com/v18.0/$ActId/ads" `
    -Body $adBody

if ($ad.Success) {
    Write-Host "✅ Ad 创建成功: $($ad.Data.id)" -ForegroundColor Green
} else {
    Write-Host "❌ Ad 创建失败!" -ForegroundColor Red
}

# ========== 最终结果 ==========

Write-Host @"

╔══════════════════════════════════════════════════╗
║              测试结果总结                          ║
╠══════════════════════════════════════════════════╣
║  Campaign:  $(if($campaign.Success){'✅'}else{'❌'}) $($campaignId)  ║
║  Ad Set:    $(if($adSet.Success){'✅'}else{'❌'}) $($adSetId)  ║
║  Creative:  $(if($creative.Success){'✅'}else{'❌'}) $($creativeId)  ║
║  Ad:        $(if($ad.Success){'✅'}else{'❌'}) $($ad.Data.id)  ║
╚══════════════════════════════════════════════════╝

"@

if ($campaign.Success) {
    Write-Host "🎉 核心结论: 浏览器 EAA token 可以调用 Facebook Marketing API 创建广告!" -ForegroundColor Green
    Write-Host ""
    Write-Host "注意事项:" -ForegroundColor Yellow
    Write-Host "  • 广告是 PAUSED 状态，需手动或在 FB Ads Manager 中启用"
    Write-Host "  • Token 1-2小时过期，长时间运行需自动刷新（扩展已支持）"
    Write-Host "  • 部分广告类型需要额外资产（Pixel、产品目录等）"
    Write-Host ""
    Write-Host "检查你的广告: https://business.facebook.com/adsmanager"
} else {
    Write-Host "❌ 测试失败" -ForegroundColor Red
    Write-Host ""
    Write-Host "如果 Campaign 都创建不了，说明浏览器 EAA token 不能调官方 Marketing API。" -ForegroundColor Yellow
    Write-Host "这种情况需要改用 Facebook 内部 API (浏览器前端用的 GraphQL/AJAX endpoint)。"
    Write-Host "告诉我测试结果，我帮你适配内部 API。"
}
