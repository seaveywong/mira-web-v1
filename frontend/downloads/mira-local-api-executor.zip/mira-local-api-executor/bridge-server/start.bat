@echo off
chcp 65001 >nul
title FB BM Toolkit Server
echo.
echo ╔══════════════════════════════════════════╗
echo ║     FB BM Toolkit Server v2.0            ║
echo ╠══════════════════════════════════════════╣
echo ║  启动中...                               ║
echo ╚══════════════════════════════════════════╝
echo.
cd /d "%~dp0"
node server.js
pause
