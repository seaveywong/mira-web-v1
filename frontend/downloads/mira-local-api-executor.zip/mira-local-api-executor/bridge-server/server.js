/**
 * FB BM Toolkit Server
 *
 * 架构:
 *   Chrome 扩展 ←→ Bridge (:9876) ←→ 远程服务器 (通过 SSH tunnel/frp)
 *
 * 职责:
 *   1. 接收浏览器推送的 token (POST /token)
 *   2. 提供最新 token 给远程服务器 (GET /token)
 *   3. 接收远程 API 调用请求 (POST /api-call)
 *   4. 扩展轮询待执行的 API 调用 (GET /jobs/next)
 *   5. 扩展回传执行结果 (POST /jobs/:id/result)
 *
 * 核心功能:
 *   - Pixel 分享: 获取 BM 列表 → BM 下像素列表 → 分享到合作伙伴 BM
 *   - BM 用户邀请: 通过 Marketing API 邀请管理员/普通用户加入 BM
 */

const http = require('http');
const crypto = require('crypto');

// ========== Config ==========

const PORT = process.env.PORT || 9876;
const HOST = process.env.HOST || '127.0.0.1'; // 仅本地访问
const API_KEY = process.env.API_KEY || crypto.randomBytes(16).toString('hex');

// ========== In-Memory Store ==========

const store = {
  /** @type {{value: string, source: string, updatedAt: number} | null} */
  eaaToken: null,
  /** @type {{value: string, updatedAt: number} | null} */
  fbDtsg: null,
  /** @type {Object<string, {value: string, updatedAt: number}>} */
  cookies: {},
  /** @type {{value: string, updatedAt: number} | null} */
  cookieString: null,
  /** @type {Map<string, {method: string, url: string, headers?: Object, body?: any, status: string, result?: any, error?: string, createdAt: number, completedAt?: number}>} */
  jobs: new Map(),
  /** @type {{id: string, name: string, valid: boolean, updatedAt: number} | null} */
  userInfo: null,
};

// Auto-cleanup jobs older than 30 minutes
setInterval(() => {
  const cutoff = Date.now() - 30 * 60 * 1000;
  for (const [id, job] of store.jobs) {
    if (job.createdAt < cutoff) {
      store.jobs.delete(id);
    }
  }
}, 5 * 60 * 1000);

// ========== Auth ==========

function checkAuth(req) {
  const auth = req.headers['authorization'];
  if (!auth) return true; // localhost 访问不需要 auth
  if (auth === `Bearer ${API_KEY}`) return true;
  return false;
}

// ========== HTTP Server ==========

const server = http.createServer(async (req, res) => {
  // CORS
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    return res.end();
  }

  // Parse body for POST
  let body = '';
  if (req.method === 'POST') {
    body = await new Promise(resolve => {
      let data = '';
      req.on('data', chunk => data += chunk);
      req.on('end', () => resolve(data));
    });
  }

  const url = new URL(req.url, `http://${HOST}:${PORT}`);
  const path = url.pathname;

  try {
    // ========== Health ==========
    if (path === '/health' && req.method === 'GET') {
      return json(res, 200, {
        status: 'ok',
        hasToken: !!store.eaaToken,
        tokenAge: store.eaaToken
          ? Math.round((Date.now() - store.eaaToken.updatedAt) / 1000)
          : null,
        pendingJobs: [...store.jobs.values()].filter(j => j.status === 'pending').length,
        uptime: process.uptime(),
      });
    }

    // ========== Token: 扩展推送 ==========
    if (path === '/token' && req.method === 'POST') {
      const data = parseBody(body);
      if (!data) return json(res, 400, { error: 'Invalid JSON body' });

      const changed = [];

      if (data.eaa_token) {
        store.eaaToken = {
          value: data.eaa_token,
          source: data.eaa_source || 'unknown',
          updatedAt: Date.now(),
        };
        changed.push('eaa_token');
      }

      if (data.fb_dtsg) {
        store.fbDtsg = {
          value: data.fb_dtsg,
          updatedAt: Date.now(),
        };
        changed.push('fb_dtsg');
      }

      if (data.cookies) {
        for (const [name, info] of Object.entries(data.cookies)) {
          store.cookies[name] = {
            value: typeof info === 'string' ? info : info.value,
            updatedAt: Date.now(),
          };
        }
        changed.push('cookies');
      }

      if (data.cookie_string) {
        store.cookieString = {
          value: data.cookie_string,
          updatedAt: Date.now(),
        };
        changed.push('cookie_string');
      }

      if (data.user_info) {
        store.userInfo = {
          ...data.user_info,
          updatedAt: Date.now(),
        };
        changed.push('user_info');
      }

      console.log(`[token] 收到推送: ${changed.join(', ')} (${new Date().toLocaleTimeString('zh-CN')})`);
      return json(res, 200, { ok: true, changed });
    }

    // ========== Token: 远程获取 ==========
    if (path === '/token' && req.method === 'GET') {
      if (!store.eaaToken) {
        return json(res, 404, { error: 'No token available', hint: '请先打开 Facebook 并确保扩展已运行' });
      }
      return json(res, 200, {
        eaa_token: store.eaaToken.value,
        eaa_source: store.eaaToken.source,
        fb_dtsg: store.fbDtsg?.value || null,
        cookie_string: store.cookieString?.value || null,
        c_user: store.cookies['c_user']?.value || null,
        xs: store.cookies['xs']?.value || null,
        user_info: store.userInfo,
        updated_at: store.eaaToken.updatedAt,
        age_seconds: Math.round((Date.now() - store.eaaToken.updatedAt) / 1000),
      });
    }

    // ========== API Call: 远程提交 ==========
    else if (path === '/api-call' && req.method === 'POST') {
      const data = parseBody(body);
      if (!data || !data.url || !data.method) {
        return json(res, 400, { error: '需要 method 和 url 字段' });
      }

      const jobId = crypto.randomUUID();
      store.jobs.set(jobId, {
        id: jobId,
        method: data.method.toUpperCase(),
        url: data.url,
        headers: data.headers || {},
        body: data.body || null,
        status: 'pending',
        createdAt: Date.now(),
      });

      console.log(`[job:${jobId}] 新任务: ${data.method} ${data.url}`);
      return json(res, 201, { job_id: jobId, status: 'pending' });
    }

    // ========== Jobs: 扩展轮询待执行任务 ==========
    else if (path === '/jobs/next' && req.method === 'GET') {
      const pending = [...store.jobs.values()]
        .filter(j => j.status === 'pending')
        .sort((a, b) => a.createdAt - b.createdAt);

      if (pending.length === 0) {
        return json(res, 200, { has_job: false });
      }

      const job = pending[0];
      job.status = 'running';
      job.startedAt = Date.now();

      console.log(`[job:${job.id}] 分派给浏览器执行`);
      return json(res, 200, {
        has_job: true,
        job: {
          id: job.id,
          method: job.method,
          url: job.url,
          headers: job.headers,
          body: job.body,
        },
      });
    }

    // ========== Jobs: 扩展回传结果 ==========
    else if (path.match(/^\/jobs\/([^/]+)\/result$/) && req.method === 'POST') {
      const jobId = path.split('/')[2];
      const job = store.jobs.get(jobId);

      if (!job) {
        return json(res, 404, { error: 'Job not found' });
      }

      const data = parseBody(body);
      job.status = data.success ? 'completed' : 'failed';
      job.result = data.result || null;
      job.error = data.error || null;
      job.statusCode = data.status_code || null;
      job.completedAt = Date.now();

      console.log(`[job:${jobId}] ${job.status}: ${job.statusCode || ''}`);
      return json(res, 200, { ok: true });
    }

    // ========== Jobs: 远程查询结果 ==========
    else if (path.match(/^\/api-call\/([^/]+)$/) && req.method === 'GET') {
      const jobId = path.split('/')[2];
      const job = store.jobs.get(jobId);

      if (!job) {
        return json(res, 404, { error: 'Job not found' });
      }

      return json(res, 200, {
        job_id: job.id,
        status: job.status,
        result: job.result || null,
        error: job.error || null,
        status_code: job.statusCode || null,
        created_at: job.createdAt,
        completed_at: job.completedAt || null,
      });
    }

    // ========== Jobs: 列出所有 ==========
    else if (path === '/jobs' && req.method === 'GET') {
      const jobs = [...store.jobs.values()]
        .sort((a, b) => b.createdAt - a.createdAt)
        .slice(0, 50)
        .map(j => ({
          id: j.id,
          method: j.method,
          url: j.url.substring(0, 80),
          status: j.status,
          status_code: j.statusCode,
          created_at: j.createdAt,
          completed_at: j.completedAt,
        }));
      return json(res, 200, { count: jobs.length, jobs });
    }

    // ========== 404 ==========
    else {
      return json(res, 404, { error: 'Not found', path });
    }

  } catch (err) {
    console.error('[error]', err.message);
    return json(res, 500, { error: err.message });
  }
});

// ========== WebSocket (可选，用于实时推送) ==========

let wss;
try {
  const { WebSocketServer } = require('ws');
  wss = new WebSocketServer({ server });

  const wsClients = new Set();

  wss.on('connection', (ws) => {
    console.log('[ws] 扩展已连接');
    wsClients.add(ws);

    // 立即推送当前 token
    if (store.eaaToken) {
      ws.send(JSON.stringify({
        type: 'token_status',
        has_token: true,
        age_seconds: Math.round((Date.now() - store.eaaToken.updatedAt) / 1000),
      }));
    }

    ws.on('message', (raw) => {
      try {
        const msg = JSON.parse(raw.toString());
        if (msg.type === 'token_push') {
          // 扩展通过 WS 推送 token
          if (msg.eaa_token) {
            store.eaaToken = {
              value: msg.eaa_token,
              source: msg.eaa_source || 'ws',
              updatedAt: Date.now(),
            };
          }
          if (msg.fb_dtsg) {
            store.fbDtsg = { value: msg.fb_dtsg, updatedAt: Date.now() };
          }
          if (msg.cookies) {
            for (const [name, info] of Object.entries(msg.cookies)) {
              store.cookies[name] = {
                value: typeof info === 'string' ? info : info.value,
                updatedAt: Date.now(),
              };
            }
          }
          console.log('[ws] 收到 token 推送');
        }
        if (msg.type === 'job_result') {
          const job = store.jobs.get(msg.job_id);
          if (job) {
            job.status = msg.success ? 'completed' : 'failed';
            job.result = msg.result || null;
            job.error = msg.error || null;
            job.completedAt = Date.now();
          }
        }
      } catch (e) { /* ignore */ }
    });

    ws.on('close', () => {
      console.log('[ws] 扩展断开');
      wsClients.delete(ws);
    });
  });

  // 有新 job 时通过 WS 推送给扩展（实时通知，不需要等轮询）
  const origSet = store.jobs.set.bind(store.jobs);
  store.jobs.set = (id, job) => {
    const isNew = !store.jobs.has(id);
    origSet(id, job);
    if (isNew && job.status === 'pending') {
      for (const ws of wsClients) {
        try {
          ws.send(JSON.stringify({
            type: 'new_job',
            job_id: job.id,
            method: job.method,
            url: job.url,
          }));
        } catch (e) { /* ignore */ }
      }
    }
    return store.jobs;
  };

} catch (err) {
  console.log('[ws] WebSocket 不可用，扩展将使用 HTTP 轮询');
}

// ========== Start ==========

server.listen(PORT, HOST, () => {
  console.log('');
  console.log('╔══════════════════════════════════════════╗');
  console.log('║     FB BM Toolkit Server v2.0            ║');
  console.log('╠══════════════════════════════════════════╣');
  console.log(`║  HTTP:     http://${HOST}:${PORT}              ║`);
  console.log(`║  Health:   http://${HOST}:${PORT}/health       ║`);
  console.log(`║  Token:    http://${HOST}:${PORT}/token        ║`);
  console.log(`║  API Call: http://${HOST}:${PORT}/api-call     ║`);
  console.log('╠══════════════════════════════════════════╣');
  console.log('║  功能:                                   ║');
  console.log('║  • Pixel 分享 (BM→像素→合作伙伴)         ║');
  console.log('║  • BM 用户邀请 (管理员/普通用户)          ║');
  console.log('╠══════════════════════════════════════════╣');
  console.log(`║  API Key:  ${API_KEY.substring(0, 8)}...       ║`);
  console.log('╚══════════════════════════════════════════╝');
  console.log('');
  console.log('等待 Chrome 扩展连接...');
  console.log('');
});

// ========== Helpers ==========

function json(res, status, data) {
  const body = JSON.stringify(data);
  res.writeHead(status, { 'Content-Type': 'application/json' });
  res.end(body + '\n');
}

function parseBody(raw) {
  if (!raw) return null;
  try {
    return JSON.parse(raw);
  } catch {
    // 尝试解析 form-encoded
    const params = new URLSearchParams(raw);
    const obj = {};
    for (const [k, v] of params) obj[k] = v;
    return Object.keys(obj).length > 0 ? obj : null;
  }
}
