#!/usr/bin/env python3
"""
FB BM Toolkit - BM 用户邀请脚本

用法:
  交互模式:  python invite-bm-user.py
  直接模式:  python invite-bm-user.py --email user@example.com --bm-id 123456 --role ADMIN
  带任务:    python invite-bm-user.py --email user@example.com --bm-id 123456 --tasks MANAGE,ADVERTISE
"""

import sys
import argparse
from bridge_helpers import BridgeClient


def main():
    parser = argparse.ArgumentParser(
        description="FB BM Toolkit - BM 用户邀请工具",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  python invite-bm-user.py                                                # 交互模式
  python invite-bm-user.py --email u@x.com --bm-id 123 --role ADMIN       # 直接邀请
  python invite-bm-user.py --email u@x.com --bm-id 123 --tasks MANAGE     # 附带任务
        """,
    )
    parser.add_argument("--email", help="被邀请人邮箱")
    parser.add_argument("--bm-id", help="Business Manager ID")
    parser.add_argument("--role", choices=["ADMIN", "EMPLOYEE"], default="EMPLOYEE", help="角色 (默认 EMPLOYEE)")
    parser.add_argument("--tasks", help="可选: 逗号分隔的任务列表 (如 MANAGE,ADVERTISE)")
    parser.add_argument("--api-version", default="v18.0", help="Facebook API 版本 (默认 v18.0)")
    args = parser.parse_args()

    client = BridgeClient()

    print("\n╔══════════════════════════════════════════════════╗")
    print("║   FB BM Toolkit - BM 用户邀请工具                ║")
    print("╚══════════════════════════════════════════════════╝")

    # 验证连接
    health = client.health()
    if not health or health.get("status") != "ok":
        print("❌ Bridge Server 未运行! 请先启动 server/start.bat")
        sys.exit(1)
    has_token = "✅" if health.get("hasToken") else "❌ 无"
    print(f"✅ Bridge Server 已连接 | Token: {has_token}")

    bm_id = args.bm_id
    email = args.email
    role = args.role

    # ========== 获取 BM (如未指定) ==========
    if not bm_id:
        print("\n========== Step 1: 获取 Business Manager 列表 ==========")

        bm_result = client.api_call(
            "GET",
            f"https://graph.facebook.com/{args.api_version}/me/businesses?fields=id,name",
            description="获取 BM 列表",
        )

        bm_list = []
        if bm_result["success"] and bm_result.get("data", {}).get("data"):
            bm_list = bm_result["data"]["data"]
            print(f"✅ 找到 {len(bm_list)} 个 Business Manager:")
            for i, bm in enumerate(bm_list):
                print(f"   {i+1}. {bm['name']} (ID: {bm['id']})")
        else:
            print("❌ 无法获取 BM 列表!")
            print("   可能原因: Token 缺少 business_management 权限")
            sys.exit(1)

        if len(bm_list) == 1:
            bm_id = bm_list[0]["id"]
            print(f"\n自动选择唯一 BM: {bm_list[0]['name']} (ID: {bm_id})")
        else:
            choice = input(f"\n选择一个 BM (1-{len(bm_list)}): ").strip()
            try:
                idx = int(choice) - 1
                if idx < 0 or idx >= len(bm_list):
                    raise ValueError
            except ValueError:
                print("❌ 无效选择")
                sys.exit(1)
            bm_id = bm_list[idx]["id"]
            print(f"📌 已选择: {bm_list[idx]['name']} (ID: {bm_id})")

    # ========== 获取 Email ==========
    if not email:
        print()
        email = input("输入要邀请的用户邮箱: ").strip()
        if not email or "@" not in email:
            print("❌ 请输入有效的邮箱地址")
            sys.exit(1)

    # ========== 选择角色 ==========
    if not args.role or args.role == "EMPLOYEE":
        print()
        print("角色选项:")
        print("  1. ADMIN    - 管理员 (完全控制)")
        print("  2. EMPLOYEE - 普通用户 (受限制)")
        role_choice = input("选择角色 (1-2, 默认 2): ").strip()
        if role_choice == "1":
            role = "ADMIN"
        else:
            role = "EMPLOYEE"

    print()
    print("📌 邀请详情:")
    print(f"   BM ID: {bm_id}")
    print(f"   邮箱:   {email}")
    print(f"   角色:   {role}")
    if args.tasks:
        print(f"   任务:   {args.tasks}")

    # ========== 可选: 查看当前用户列表 ==========
    show_users = input("\n是否先查看 BM 当前用户列表? (y/N): ").strip()
    if show_users.lower() in ("y", "yes"):
        print("\n========== 当前 BM 用户 ==========")
        users_result = client.api_call(
            "GET",
            f"https://graph.facebook.com/{args.api_version}/{bm_id}/users?fields=id,name,email,role,status",
            description=f"获取 BM {bm_id} 用户列表",
        )

        if users_result["success"] and users_result.get("data", {}).get("data"):
            user_list = users_result["data"]["data"]
            print(f"当前 BM 用户 ({len(user_list)} 人):")
            for u in user_list:
                print(f"   {u.get('name', 'N/A')} | {u.get('email', 'N/A')} | {u.get('role', 'N/A')} | {u.get('status', 'N/A')}")
        else:
            print("⚠️ 无法获取用户列表 (可能权限不足)")

    # ========== 发送邀请 ==========
    print("\n========== 发送邀请 ==========")

    confirm = input("确认发送邀请? (y/N): ").strip()
    if confirm.lower() not in ("y", "yes"):
        print("已取消")
        sys.exit(0)

    invite_body = {
        "email": email,
        "role": role,
    }

    if args.tasks:
        invite_body["tasks"] = [t.strip() for t in args.tasks.split(",")]

    print(f"\n📤 发送邀请: {email} → BM {bm_id} (角色: {role})")

    invite_result = client.api_call(
        "POST",
        f"https://graph.facebook.com/{args.api_version}/{bm_id}/users",
        invite_body,
        description=f"邀请 {email} → BM {bm_id}",
    )

    if invite_result["success"]:
        print(f"\n🎉 邀请已发送!")
        print(f"   用户 {email} 将收到 Facebook 通知")
        print(f"   角色: {role}")
        if args.tasks:
            print(f"   任务权限: {args.tasks}")
        print()
        print("💡 提示: 用户需要在 Facebook 中接受邀请才能加入 BM")
    else:
        print("\n❌ 邀请发送失败")
        err_str = str(invite_result.get("error", ""))
        if err_str:
            print(f"   错误: {err_str}")

        if "already" in err_str.lower() or "invited" in err_str.lower():
            print("   💡 该用户可能已被邀请或已是 BM 成员")
        elif "permission" in err_str.lower():
            print("   💡 请确认 Token 有 business_management 权限")
        elif "email" in err_str.lower():
            print("   💡 请检查邮箱地址格式是否正确")

        if invite_result.get("data"):
            import json
            print(f"   API 响应: {json.dumps(invite_result['data'], indent=2, ensure_ascii=False)}")


if __name__ == "__main__":
    main()
