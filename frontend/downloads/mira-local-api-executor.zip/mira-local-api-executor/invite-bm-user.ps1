# FB BM Toolkit - BM 用户邀请脚本
# 通过 Marketing API 邀请用户加入 Business Manager (管理员/普通用户)
#
# 用法:
#   交互模式: .\invite-bm-user.ps1
#   直接模式: .\invite-bm-user.ps1 -Email "user@example.com" -BmId "123456" -Role ADMIN
#   带任务:   .\invite-bm-user.ps1 -Email "user@example.com" -BmId "123456" -Role EMPLOYEE -Tasks "MANAGE,ADVERTISE"

param(
    [string]$Email,                # 被邀请人邮箱
    [string]$BmId,                 # Business Manager ID
    [ValidateSet("ADMIN", "EMPLOYEE")] [string]$Role = "EMPLOYEE",
    [string]$Tasks,                # 可选: 逗号分隔的任务列表
    [string]$ApiVersion = "v18.0"
)

$ErrorActionPreference = "Continue"

# 加载共享辅助函数
. "$PSScriptRoot\bridge-helpers.ps1"

# ========== 主流程 ==========

Write-BridgeBanner "BM 用户邀请工具"

# 验证 Bridge 连接
$health = Get-BridgeHealth
if (-not $health -or $health.status -ne "ok") {
    Write-Host "❌ Bridge Server 未运行! 请先启动 server/start.bat" -ForegroundColor Red
    exit 1
}
Write-Host "✅ Bridge Server 已连接 | Token: $(if($health.hasToken){'✅'}else{'❌ 无'})"

# ========== 获取 BM (如未指定) ==========

if (-not $BmId) {
    Write-BridgeStep "Step 1: 获取 Business Manager 列表"

    $bmResult = Invoke-BridgeApi -Method GET `
        -Url "https://graph.facebook.com/$ApiVersion/me/businesses?fields=id,name" `
        -Description "获取 BM 列表"

    $bmList = @()
    if ($bmResult.Success -and $bmResult.Data.data) {
        $bmList = $bmResult.Data.data
        Write-Host "✅ 找到 $($bmList.Count) 个 Business Manager:" -ForegroundColor Green
        for ($i = 0; $i -lt $bmList.Count; $i++) {
            $bm = $bmList[$i]
            Write-Host "   $($i+1). $($bm.name) (ID: $($bm.id))"
        }
    } else {
        Write-Host "❌ 无法获取 BM 列表!" -ForegroundColor Red
        Write-Host "   可能原因: Token 缺少 business_management 权限"
        exit 1
    }

    if ($bmList.Count -eq 1) {
        $BmId = $bmList[0].id
        Write-Host "`n自动选择唯一 BM: $($bmList[0].name) (ID: $BmId)"
    } else {
        $choice = Read-Host "`n选择一个 BM (输入编号)"
        $idx = [int]$choice - 1
        if ($idx -lt 0 -or $idx -ge $bmList.Count) {
            Write-Host "❌ 无效选择" -ForegroundColor Red
            exit 1
        }
        $BmId = $bmList[$idx].id
        $selectedBmName = $bmList[$idx].name
        Write-Host "📌 已选择: $selectedBmName (ID: $BmId)"
    }
}

# ========== 获取 Email (如未指定) ==========

if (-not $Email) {
    Write-Host ""
    $Email = Read-Host "输入要邀请的用户邮箱"
    if (-not $Email -or $Email -notmatch '@') {
        Write-Host "❌ 请输入有效的邮箱地址" -ForegroundColor Red
        exit 1
    }
}

# ========== 选择角色 ==========

if (-not $Role) {
    Write-Host ""
    Write-Host "角色选项:" -ForegroundColor Cyan
    Write-Host "  1. ADMIN    - 管理员 (完全控制)"
    Write-Host "  2. EMPLOYEE - 普通用户 (受限制)"
    $roleChoice = Read-Host "选择角色 (1-2, 默认 2)"
    if ($roleChoice -eq "1") {
        $Role = "ADMIN"
    } else {
        $Role = "EMPLOYEE"
    }
}

Write-Host ""
Write-Host "📌 邀请详情:" -ForegroundColor Cyan
Write-Host "   BM ID: $BmId"
Write-Host "   邮箱:   $Email"
Write-Host "   角色:   $Role"
if ($Tasks) {
    Write-Host "   任务:   $Tasks"
}

# ========== 可选: 查看当前用户列表 ==========

$showUsers = Read-Host "`n是否先查看 BM 当前用户列表? (y/N)"
if ($showUsers -match '^[yY]') {
    Write-BridgeStep "当前 BM 用户"

    $usersResult = Invoke-BridgeApi -Method GET `
        -Url "https://graph.facebook.com/$ApiVersion/$BmId/users?fields=id,name,email,role,status" `
        -Description "获取 BM $BmId 用户列表"

    if ($usersResult.Success -and $usersResult.Data.data) {
        $userList = $usersResult.Data.data
        Write-Host "当前 BM 用户 ($($userList.Count) 人):" -ForegroundColor Green
        foreach ($u in $userList) {
            Write-Host "   $($u.name) | $($u.email) | $($u.role) | $($u.status)"
        }
    } else {
        Write-Host "⚠️ 无法获取用户列表 (可能权限不足)" -ForegroundColor Yellow
    }
}

# ========== 发送邀请 ==========

Write-BridgeStep "发送邀请"

$confirm = Read-Host "确认发送邀请? (y/N)"
if ($confirm -notmatch '^[yY]') {
    Write-Host "已取消" -ForegroundColor Yellow
    exit 0
}

# 构建请求体
$inviteBody = @{
    email = $Email
    role  = $Role
}

# 添加任务分配 (如果指定)
if ($Tasks) {
    $taskArray = $Tasks -split ',' | ForEach-Object { $_.Trim() }
    $inviteBody.tasks = $taskArray
}

Write-Host "`n📤 发送邀请: $Email → BM $BmId (角色: $Role)"

$inviteResult = Invoke-BridgeApi -Method POST `
    -Url "https://graph.facebook.com/$ApiVersion/$BmId/users" `
    -Body $inviteBody `
    -Description "邀请 $Email → BM $BmId"

if ($inviteResult.Success) {
    Write-Host "`n🎉 邀请已发送!" -ForegroundColor Green
    Write-Host "   用户 $Email 将收到 Facebook 通知"
    Write-Host "   角色: $Role"
    if ($Tasks) {
        Write-Host "   任务权限: $Tasks"
    }
    Write-Host ""
    Write-Host "💡 提示: 用户需要在 Facebook 中接受邀请才能加入 BM" -ForegroundColor Yellow
} else {
    Write-Host "`n❌ 邀请发送失败" -ForegroundColor Red
    if ($inviteResult.Error) {
        $errStr = if ($inviteResult.Error -is [string]) { $inviteResult.Error } else { $inviteResult.Error | ConvertTo-Json -Depth 3 }
        Write-Host "   错误: $errStr"

        # 常见错误提示
        if ($errStr -match "already|已存在|invited") {
            Write-Host "   💡 该用户可能已被邀请或已是 BM 成员" -ForegroundColor Yellow
        } elseif ($errStr -match "permission|权限") {
            Write-Host "   💡 请确认 Token 有 business_management 权限" -ForegroundColor Yellow
        } elseif ($errStr -match "email") {
            Write-Host "   💡 请检查邮箱地址格式是否正确" -ForegroundColor Yellow
        }
    }
    if ($inviteResult.Data) {
        Write-Host "   API 响应: $($inviteResult.Data | ConvertTo-Json -Depth 3)"
    }
}
