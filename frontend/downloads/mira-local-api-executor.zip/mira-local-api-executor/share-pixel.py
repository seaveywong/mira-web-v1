#!/usr/bin/env python3
"""
FB BM Toolkit - Pixel 分享脚本

用法:
  交互模式:   python share-pixel.py
  直接模式:   python share-pixel.py --pixel-id 123456 --partner-bm-id 789012
  指定BM:     python share-pixel.py --bm-id 123456
"""

import sys
import argparse
from bridge_helpers import BridgeClient


def main():
    parser = argparse.ArgumentParser(
        description="FB BM Toolkit - Pixel 分享工具",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  python share-pixel.py                                    # 交互模式
  python share-pixel.py --pixel-id 123 --partner-bm-id 456 # 直接分享
  python share-pixel.py --bm-id 123456 --api-version v19.0 # 指定 BM
        """,
    )
    parser.add_argument("--pixel-id", help="直接模式: 要分享的 Pixel ID")
    parser.add_argument("--partner-bm-id", help="直接模式: 合作伙伴 BM ID")
    parser.add_argument("--bm-id", help="指定 BM ID (跳过 BM 选择)")
    parser.add_argument("--api-version", default="v18.0", help="Facebook API 版本 (默认 v18.0)")
    args = parser.parse_args()

    client = BridgeClient()

    print("\n╔══════════════════════════════════════════════════╗")
    print("║   FB BM Toolkit - Pixel 分享工具                 ║")
    print("╚══════════════════════════════════════════════════╝")

    # 验证连接
    health = client.health()
    if not health or health.get("status") != "ok":
        print("❌ Bridge Server 未运行! 请先启动 server/start.bat")
        sys.exit(1)
    has_token = "✅" if health.get("hasToken") else "❌ 无"
    print(f"✅ Bridge Server 已连接 | Token: {has_token} | 年龄: {health.get('tokenAge')}s")

    # ========== 直接模式 ==========
    if args.pixel_id and args.partner_bm_id:
        print(f"\n📌 直接分享模式: Pixel {args.pixel_id} → BM {args.partner_bm_id}")

        share_body = {"business": args.partner_bm_id}
        result = client.api_call(
            "POST",
            f"https://graph.facebook.com/{args.api_version}/{args.pixel_id}/shared_agencies",
            share_body,
            description=f"分享 Pixel {args.pixel_id} → BM {args.partner_bm_id}",
        )

        if result["success"]:
            print("\n🎉 Pixel 分享成功!")
        else:
            print("\n❌ Pixel 分享失败")
            if result.get("data"):
                import json
                print(f"   响应: {json.dumps(result['data'], indent=2, ensure_ascii=False)}")
        sys.exit(0 if result["success"] else 1)

    # ========== Step 1: 获取 BM 列表 ==========
    print("\n========== Step 1: 获取 Business Manager 列表 ==========")

    bm_result = client.api_call(
        "GET",
        f"https://graph.facebook.com/{args.api_version}/me/businesses?fields=id,name,primary_page",
        description="获取 BM 列表",
    )

    bm_list = []
    if bm_result["success"] and bm_result.get("data", {}).get("data"):
        bm_list = bm_result["data"]["data"]
        print(f"✅ 找到 {len(bm_list)} 个 Business Manager:")
        for i, bm in enumerate(bm_list):
            print(f"   {i+1}. {bm['name']} (ID: {bm['id']})")
    else:
        print("❌ 无法获取 BM 列表!")
        print("   可能原因: Token 缺少 business_management 权限")
        sys.exit(1)

    # 选择 BM
    if args.bm_id:
        selected_bm = next((b for b in bm_list if b["id"] == args.bm_id), None)
        if not selected_bm:
            print(f"❌ 未找到 BM ID: {args.bm_id}")
            sys.exit(1)
        print(f"\n使用指定 BM: {selected_bm['name']} (ID: {selected_bm['id']})")
    elif len(bm_list) == 1:
        selected_bm = bm_list[0]
        print(f"\n自动选择唯一 BM: {selected_bm['name']}")
    else:
        choice = input(f"\n选择 BM (1-{len(bm_list)}): ").strip()
        try:
            idx = int(choice) - 1
            if idx < 0 or idx >= len(bm_list):
                raise ValueError
        except ValueError:
            print("❌ 无效选择")
            sys.exit(1)
        selected_bm = bm_list[idx]

    bm_id = selected_bm["id"]
    print(f"📌 已选择: {selected_bm['name']} (ID: {bm_id})")

    # ========== Step 2: 获取像素 ==========
    print(f"\n========== Step 2: 获取 BM ({selected_bm['name']}) 下的像素 ==========")

    pixel_result = client.api_call(
        "GET",
        f"https://graph.facebook.com/{args.api_version}/{bm_id}/owned_pixels?fields=id,name,code,creation_time,last_fired_time",
        description=f"获取 BM {bm_id} 的像素列表",
    )

    pixel_list = []
    if pixel_result["success"] and pixel_result.get("data", {}).get("data"):
        pixel_list = pixel_result["data"]["data"]
        print(f"✅ 找到 {len(pixel_list)} 个像素:")
        for i, px in enumerate(pixel_list):
            last_fired = f"最后触发: {px.get('last_fired_time', '未触发')}"
            print(f"   {i+1}. {px['name']} (ID: {px['id']}) | Code: {px.get('code', 'N/A')} | {last_fired}")
    else:
        print("❌ 无法获取像素列表!")
        print("   该 BM 可能没有像素，或 Token 权限不足")
        if pixel_result.get("data"):
            import json
            print(f"   API 响应: {json.dumps(pixel_result['data'], indent=2, ensure_ascii=False)}")
        sys.exit(1)

    if not pixel_list:
        print("⚠️ 该 BM 下没有像素，无需分享")
        sys.exit(0)

    # 选择像素
    choice = input(f"\n选择要分享的像素 (1-{len(pixel_list)}): ").strip()
    try:
        idx = int(choice) - 1
        if idx < 0 or idx >= len(pixel_list):
            raise ValueError
    except ValueError:
        print("❌ 无效选择")
        sys.exit(1)
    selected_pixel = pixel_list[idx]
    print(f"📌 已选择像素: {selected_pixel['name']} (ID: {selected_pixel['id']})")

    # ========== Step 3: 分享到合作伙伴 ==========
    print("\n========== Step 3: 分享像素到合作伙伴 BM ==========")

    partner_bm_id = input("输入合作伙伴的 Business Manager ID: ").strip()
    if not partner_bm_id:
        print("❌ 合作伙伴 BM ID 不能为空")
        sys.exit(1)

    print(f"\n📤 分享像素:")
    print(f"   像素: {selected_pixel['name']} (ID: {selected_pixel['id']})")
    print(f"   来自: {selected_bm['name']} (BM ID: {bm_id})")
    print(f"   目标: BM ID: {partner_bm_id}")

    confirm = input("\n确认分享? (y/N): ").strip()
    if confirm.lower() not in ("y", "yes"):
        print("已取消")
        sys.exit(0)

    share_body = {"business": partner_bm_id}
    share_result = client.api_call(
        "POST",
        f"https://graph.facebook.com/{args.api_version}/{selected_pixel['id']}/shared_agencies",
        share_body,
        description=f"分享像素 {selected_pixel['id']} → BM {partner_bm_id}",
    )

    if share_result["success"]:
        print(f"\n🎉 像素分享成功!")
        print(f"   合作伙伴 BM {partner_bm_id} 现在可以访问像素 {selected_pixel['name']}")
    else:
        print("\n❌ 像素分享失败")
        err_str = str(share_result.get("error", ""))
        if err_str:
            print(f"   错误: {err_str}")
        if "permission" in err_str.lower():
            print("   💡 请确认 Token 有 business_management 权限")
        elif "not found" in err_str.lower():
            print("   💡 请检查合作伙伴 BM ID 是否正确")
        elif "already" in err_str.lower():
            print("   💡 该像素可能已经分享给此 BM")


if __name__ == "__main__":
    main()
