"""
FB BM Toolkit - 共享 Python 辅助模块

提供 BridgeClient 类，封装与 Bridge Server 的所有通信。
"""

import json
import time
import urllib.request
import urllib.error


class BridgeClient:
    """FB BM Toolkit Bridge 客户端

    用法:
        client = BridgeClient()
        client.health()
        client.api_call("GET", "https://graph.facebook.com/v18.0/me")
    """

    def __init__(self, base_url="http://127.0.0.1:9876", timeout=120):
        self.base_url = base_url
        self.timeout = timeout
        self.job_count = 0

    # ========== 基础 API ==========

    def health(self):
        """健康检查"""
        try:
            req = urllib.request.Request(f"{self.base_url}/health")
            resp = urllib.request.urlopen(req)
            return json.loads(resp.read())
        except urllib.error.HTTPError as e:
            body = e.read().decode()
            return {"error": f"HTTP {e.code}: {body}"}
        except Exception as e:
            return {"error": f"连接失败: {e}"}

    def token(self):
        """获取最新的 EAA Token"""
        try:
            req = urllib.request.Request(f"{self.base_url}/token")
            resp = urllib.request.urlopen(req)
            return json.loads(resp.read())
        except urllib.error.HTTPError as e:
            body = e.read().decode()
            print(f"❌ HTTP {e.code}: {body}")
            return None
        except Exception as e:
            print(f"❌ 连接失败: {e}")
            print("   请确认 Bridge Server 已启动")
            return None

    def submit_job(self, method, url, body=None, headers=None):
        """提交 API 调用任务，返回 job_id"""
        payload = {
            "method": method.upper(),
            "url": url,
        }
        if body is not None:
            payload["body"] = body
        if headers is not None:
            payload["headers"] = headers

        try:
            req = urllib.request.Request(
                f"{self.base_url}/api-call",
                data=json.dumps(payload).encode(),
                headers={"Content-Type": "application/json"},
            )
            resp = urllib.request.urlopen(req)
            result = json.loads(resp.read())
            return result.get("job_id")
        except Exception as e:
            print(f"❌ 提交任务失败: {e}")
            return None

    def wait_job(self, job_id, timeout=None):
        """轮询等待任务完成，返回 {success, data, error, status_code}"""
        if timeout is None:
            timeout = self.timeout

        start = time.time()
        while time.time() - start < timeout:
            time.sleep(1.5)
            try:
                req = urllib.request.Request(f"{self.base_url}/api-call/{job_id}")
                resp = urllib.request.urlopen(req)
                data = json.loads(resp.read())

                status = data.get("status")
                if status == "completed":
                    return {
                        "success": True,
                        "data": data.get("result"),
                        "status_code": data.get("status_code"),
                        "error": None,
                    }
                if status == "failed":
                    return {
                        "success": False,
                        "data": data.get("result"),
                        "status_code": data.get("status_code"),
                        "error": data.get("error"),
                    }
            except Exception:
                pass

            elapsed = int(time.time() - start)
            print(f"\r   ⏳ {elapsed}s", end="", flush=True)

        print(f"\n   ⏰ 超时 ({timeout}s)")
        return {"success": False, "error": f"Timeout after {timeout}s", "data": None, "status_code": None}

    def api_call(self, method, url, body=None, description=""):
        """一步完成: 提交任务 + 轮询结果"""
        self.job_count += 1
        label = description or f"{method} {url[:80]}"
        print(f"\n📤 Job #{self.job_count}: {label}")

        job_id = self.submit_job(method, url, body)
        if not job_id:
            return {"success": False, "error": "Failed to submit job"}

        result = self.wait_job(job_id)

        if result["success"]:
            print(f"   ✅ 成功 (HTTP {result['status_code']})")
        else:
            print(f"   ❌ 失败 (HTTP {result.get('status_code')})")
            if result.get("error"):
                err_str = str(result["error"])
                if len(err_str) > 300:
                    err_str = err_str[:300] + "..."
                print(f"   {err_str}")

        return result

    def list_jobs(self):
        """列出最近的 job"""
        try:
            req = urllib.request.Request(f"{self.base_url}/jobs")
            resp = urllib.request.urlopen(req)
            return json.loads(resp.read())
        except Exception as e:
            print(f"❌ 连接失败: {e}")
            return None
