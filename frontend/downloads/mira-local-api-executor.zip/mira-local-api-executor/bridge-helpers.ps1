# FB BM Toolkit - 共享 PowerShell 辅助函数
# 所有 .ps1 脚本 dot-source 此文件: . "$PSScriptRoot\bridge-helpers.ps1"

$script:BridgeUrl = "http://127.0.0.1:9876"
$script:JobTimeout = 120  # 默认超时秒数

# ========== 核心函数 ==========

function Get-BridgeHealth {
    <#
    .SYNOPSIS
        健康检查 Bridge Server
    #>
    try {
        $response = Invoke-RestMethod -Uri "$script:BridgeUrl/health" -Method GET -TimeoutSec 5
        return $response
    } catch {
        Write-Host "❌ Bridge Server 未运行: $_" -ForegroundColor Red
        Write-Host "   请先启动: fb-bm-toolkit\server\start.bat" -ForegroundColor Yellow
        return $null
    }
}

function Get-BridgeToken {
    <#
    .SYNOPSIS
        获取当前 Facebook EAA Token
    #>
    try {
        $response = Invoke-RestMethod -Uri "$script:BridgeUrl/token" -Method GET -TimeoutSec 5
        return $response
    } catch {
        Write-Host "❌ 获取 Token 失败: $_" -ForegroundColor Red
        Write-Host "   请确认 Bridge Server 已启动且 Chrome 扩展已连接" -ForegroundColor Yellow
        return $null
    }
}

function Submit-BridgeJob {
    <#
    .SYNOPSIS
        提交 API 调用任务到 Bridge
    .PARAMETER Method
        HTTP 方法 (GET/POST/DELETE)
    .PARAMETER Url
        完整的 Facebook API URL
    .PARAMETER Body
        请求体 (PSObject 或 Hashtable，可选)
    .PARAMETER Headers
        自定义请求头 (Hashtable，可选)
    #>
    param(
        [Parameter(Mandatory=$true)] [string]$Method,
        [Parameter(Mandatory=$true)] [string]$Url,
        $Body = $null,
        [hashtable]$Headers = @{}
    )

    $payload = @{
        method  = $Method.ToUpper()
        url     = $Url
        headers = $Headers
    }
    if ($Body) { $payload.body = $Body }

    try {
        $result = Invoke-RestMethod -Uri "$script:BridgeUrl/api-call" -Method POST `
            -Body ($payload | ConvertTo-Json -Depth 10) `
            -ContentType "application/json" -TimeoutSec 5
        return $result.job_id
    } catch {
        Write-Host "❌ 提交任务失败: $_" -ForegroundColor Red
        return $null
    }
}

function Wait-BridgeJob {
    <#
    .SYNOPSIS
        轮询等待任务完成
    .PARAMETER JobId
        任务 ID
    .PARAMETER Timeout
        超时秒数，默认 120
    #>
    param(
        [Parameter(Mandatory=$true)] [string]$JobId,
        [int]$Timeout = $script:JobTimeout
    )

    $start = Get-Date
    while (((Get-Date) - $start).TotalSeconds -lt $Timeout) {
        Start-Sleep -Milliseconds 1500
        try {
            $result = Invoke-RestMethod -Uri "$script:BridgeUrl/api-call/$JobId" -Method GET -TimeoutSec 5

            if ($result.status -eq "completed") {
                return @{ Success = $true; Data = $result.result; StatusCode = $result.status_code }
            }
            if ($result.status -eq "failed") {
                return @{ Success = $false; Error = $result.error; StatusCode = $result.status_code; Data = $result.result }
            }
        } catch { }
        $elapsed = [math]::Round(((Get-Date) - $start).TotalSeconds)
        Write-Host "`r   ⏳ ${elapsed}s" -NoNewline
    }
    Write-Host ""
    Write-Host "   ⏰ 超时 (${Timeout}s)" -ForegroundColor Yellow
    return @{ Success = $false; Error = "Timeout after ${Timeout}s" }
}

function Invoke-BridgeApi {
    <#
    .SYNOPSIS
        一步完成: 提交任务 + 轮询结果 (最常用的便捷函数)
    .PARAMETER Method
        HTTP 方法
    .PARAMETER Url
        Facebook API URL
    .PARAMETER Body
        请求体 (可选)
    .PARAMETER Description
        任务描述，用于日志输出
    #>
    param(
        [Parameter(Mandatory=$true)] [string]$Method,
        [Parameter(Mandatory=$true)] [string]$Url,
        $Body = $null,
        [string]$Description = ""
    )

    $script:JobCount++
    $label = if ($Description) { $Description } else { "$Method $($Url.Substring(0, [Math]::Min(80, $Url.Length)))" }
    Write-Host "`n📤 Job #$script:JobCount : $label" -ForegroundColor Cyan

    $jobId = Submit-BridgeJob -Method $Method -Url $Url -Body $Body
    if (-not $jobId) {
        return @{ Success = $false; Error = "Failed to submit job" }
    }

    $result = Wait-BridgeJob -JobId $jobId

    if ($result.Success) {
        Write-Host "   ✅ 成功 (HTTP $($result.StatusCode))" -ForegroundColor Green
    } else {
        Write-Host "   ❌ 失败 (HTTP $($result.StatusCode))" -ForegroundColor Red
        if ($result.Error) {
            $errStr = if ($result.Error -is [string]) { $result.Error } else { $result.Error | ConvertTo-Json -Depth 3 }
            Write-Host "   $($errStr.Substring(0, [Math]::Min(300, $errStr.Length)))" -ForegroundColor DarkRed
        }
    }
    return $result
}

function Get-BridgeJobs {
    <#
    .SYNOPSIS
        列出最近的 job
    #>
    try {
        $response = Invoke-RestMethod -Uri "$script:BridgeUrl/jobs" -Method GET -TimeoutSec 5
        return $response
    } catch {
        Write-Host "❌ 获取 Jobs 失败: $_" -ForegroundColor Red
        return $null
    }
}

# ========== 输出辅助 ==========

function Write-BridgeStep {
    param([string]$Title)
    Write-Host "`n========== $Title ==========" -ForegroundColor Yellow
}

function Write-BridgeBanner {
    param([string]$Title)
    Write-Host @"

╔══════════════════════════════════════════════════╗
║   FB BM Toolkit - $Title
╚══════════════════════════════════════════════════╝
"@ -ForegroundColor White
}

# ========== 初始化 ==========

$script:JobCount = 0
