#!/usr/bin/env python3
"""
FB BM Toolkit - 通用测试客户端 (Python)

用法:
  python test-client.py token
  python test-client.py health
  python test-client.py call GET "https://graph.facebook.com/v18.0/me"
  python test-client.py call POST "https://graph.facebook.com/v18.0/act_123/campaigns" '{"name":"test"}'
  python test-client.py jobs
  python test-client.py share-pixel
  python test-client.py invite-user
"""

import sys
import json
from bridge_helpers import BridgeClient

client = BridgeClient()


def cmd_health():
    data = client.health()
    print(json.dumps(data, indent=2, ensure_ascii=False))


def cmd_token():
    data = client.token()
    if data:
        print(json.dumps(data, indent=2, ensure_ascii=False))


def cmd_call(args):
    if len(args) < 2:
        print("用法: python test-client.py call <method> <url> [body_json]")
        sys.exit(1)
    method = args[0]
    url = args[1]
    body = None
    if len(args) > 2:
        try:
            body = json.loads(args[2])
        except json.JSONDecodeError:
            body = args[2]

    result = client.api_call(method, url, body)
    if result.get("data"):
        print(json.dumps(result["data"], indent=2, ensure_ascii=False)[:2000])


def cmd_jobs():
    data = client.list_jobs()
    if data:
        print(json.dumps(data, indent=2, ensure_ascii=False))


def cmd_share_pixel():
    import subprocess
    subprocess.run([sys.executable, "share-pixel.py"])


def cmd_invite_user():
    import subprocess
    subprocess.run([sys.executable, "invite-bm-user.py"])


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)

    cmd = sys.argv[1]

    if cmd == "token":
        cmd_token()
    elif cmd == "health":
        cmd_health()
    elif cmd == "call":
        cmd_call(sys.argv[2:])
    elif cmd == "jobs":
        cmd_jobs()
    elif cmd == "share-pixel":
        cmd_share_pixel()
    elif cmd == "invite-user":
        cmd_invite_user()
    else:
        print(f"未知命令: {cmd}")
        print(__doc__)
