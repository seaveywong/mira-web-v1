# FB BM Toolkit - 通用测试客户端 (PowerShell)
# 配合 bridge-helpers.ps1 使用
#
# 用法:
#   .\test-client.ps1 health
#   .\test-client.ps1 token
#   .\test-client.ps1 call GET "https://graph.facebook.com/v18.0/me"
#   .\test-client.ps1 call POST "https://graph.facebook.com/v18.0/act_123/campaigns" '{"name":"test"}'
#   .\test-client.ps1 jobs
#   .\test-client.ps1 share-pixel
#   .\test-client.ps1 invite-user

param(
    [Parameter(Position=0)]
    [string]$Command = "health",

    [Parameter(Position=1)]
    [string]$Arg1 = "",

    [Parameter(Position=2)]
    [string]$Arg2 = "",

    [Parameter(Position=3)]
    [string]$Arg3 = ""
)

$ErrorActionPreference = "Continue"

# 加载共享辅助函数
. "$PSScriptRoot\bridge-helpers.ps1"

switch ($Command) {
    "health" {
        Get-BridgeHealth
    }
    "token" {
        $token = Get-BridgeToken
        if ($token) {
            Write-Host "✅ Token 已获取" -ForegroundColor Green
            Write-Host "   EAA: $($token.eaa_token.Substring(0, [Math]::Min(30, $token.eaa_token.Length)))..."
            Write-Host "   c_user: $($token.c_user)"
            Write-Host "   年龄: $($token.age_seconds)s"
            Write-Host "   fb_dtsg: $($token.fb_dtsg)"
        }
    }
    "call" {
        if (-not $Arg1 -or -not $Arg2) {
            Write-Host "用法: .\test-client.ps1 call <method> <url> [body_json]"
            exit 1
        }
        $body = if ($Arg3) {
            try { $Arg3 | ConvertFrom-Json } catch { $Arg3 }
        } else { $null }
        Invoke-BridgeApi -Method $Arg1 -Url $Arg2 -Body $body
    }
    "jobs" {
        Get-BridgeJobs
    }
    "share-pixel" {
        # 启动 Pixel 分享脚本
        & "$PSScriptRoot\share-pixel.ps1" @PSBoundParameters
    }
    "invite-user" {
        # 启动 BM 用户邀请脚本
        & "$PSScriptRoot\invite-bm-user.ps1" @PSBoundParameters
    }
    default {
        Write-Host @"
FB BM Toolkit - 通用测试客户端

用法:
  .\test-client.ps1 health              # 健康检查
  .\test-client.ps1 token               # 获取最新 token
  .\test-client.ps1 call GET "https://graph.facebook.com/v18.0/me"  # API 调用
  .\test-client.ps1 call POST "https://graph.facebook.com/v18.0/act_123/campaigns" '{"name":"test"}'
  .\test-client.ps1 jobs                # 查看最近 job
  .\test-client.ps1 share-pixel         # Pixel 分享 (交互)
  .\test-client.ps1 invite-user         # BM 用户邀请 (交互)

核心功能脚本:
  .\share-pixel.ps1                     # Pixel 分享工具
  .\invite-bm-user.ps1                  # BM 用户邀请工具
  .\test-create-ad.ps1                  # 广告创建测试
"@
    }
}
