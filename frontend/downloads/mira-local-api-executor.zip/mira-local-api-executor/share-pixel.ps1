# FB BM Toolkit - Pixel 分享脚本
# 获取 BM 列表 → 获取 BM 下像素 → 分享像素到合作伙伴 BM
#
# 用法:
#   交互模式: .\share-pixel.ps1
#   直接模式: .\share-pixel.ps1 -PixelId "123456" -PartnerBmId "789012"
#   指定BM:   .\share-pixel.ps1 -BmId "123456"

param(
    [string]$PixelId,              # 直接模式: 指定要分享的 Pixel ID
    [string]$PartnerBmId,          # 直接模式: 指定合作伙伴 BM ID
    [string]$BmId,                 # 可选: 过滤 BM
    [string]$ApiVersion = "v18.0"
)

$ErrorActionPreference = "Continue"

# 加载共享辅助函数
. "$PSScriptRoot\bridge-helpers.ps1"

# ========== 主流程 ==========

Write-BridgeBanner "Pixel 分享工具"

# 验证 Bridge 连接
$health = Get-BridgeHealth
if (-not $health -or $health.status -ne "ok") {
    Write-Host "❌ Bridge Server 未运行! 请先启动 server/start.bat" -ForegroundColor Red
    exit 1
}
Write-Host "✅ Bridge Server 已连接 | Token: $(if($health.hasToken){'✅'}else{'❌ 无'}) | 年龄: $($health.tokenAge)s"

# ========== 直接模式 ==========
if ($PixelId -and $PartnerBmId) {
    Write-Host "`n📌 直接分享模式: Pixel $PixelId → BM $PartnerBmId" -ForegroundColor Cyan

    $shareBody = @{
        business = $PartnerBmId
    }

    $result = Invoke-BridgeApi -Method POST `
        -Url "https://graph.facebook.com/$ApiVersion/$PixelId/shared_agencies" `
        -Body $shareBody `
        -Description "分享 Pixel $PixelId 到 BM $PartnerBmId"

    if ($result.Success) {
        Write-Host "`n🎉 Pixel 分享成功!" -ForegroundColor Green
    } else {
        Write-Host "`n❌ Pixel 分享失败" -ForegroundColor Red
        if ($result.Data) {
            Write-Host "   响应: $($result.Data | ConvertTo-Json -Depth 3)"
        }
    }
    exit $(if($result.Success){0}else{1})
}

# ========== Step 1: 获取 BM 列表 ==========

Write-BridgeStep "Step 1: 获取 Business Manager 列表"

$bmResult = Invoke-BridgeApi -Method GET `
    -Url "https://graph.facebook.com/$ApiVersion/me/businesses?fields=id,name,primary_page,profile_picture_uri" `
    -Description "获取 BM 列表"

$bmList = @()
if ($bmResult.Success -and $bmResult.Data.data) {
    $bmList = $bmResult.Data.data
    Write-Host "✅ 找到 $($bmList.Count) 个 Business Manager:" -ForegroundColor Green
    for ($i = 0; $i -lt $bmList.Count; $i++) {
        $bm = $bmList[$i]
        Write-Host "   $($i+1). $($bm.name) (ID: $($bm.id))"
    }
} else {
    Write-Host "❌ 无法获取 BM 列表!" -ForegroundColor Red
    Write-Host "   可能原因: Token 缺少 business_management 权限"
    exit 1
}

# 选择 BM
if ($BmId) {
    $selectedBm = $bmList | Where-Object { $_.id -eq $BmId }
    if (-not $selectedBm) {
        Write-Host "❌ 未找到 BM ID: $BmId" -ForegroundColor Red
        exit 1
    }
    Write-Host "`n使用指定 BM: $($selectedBm.name) (ID: $($selectedBm.id))"
} elseif ($bmList.Count -eq 1) {
    $selectedBm = $bmList[0]
    Write-Host "`n自动选择唯一 BM: $($selectedBm.name)"
} else {
    $choice = Read-Host "`n选择 BM (输入编号)"
    $idx = [int]$choice - 1
    if ($idx -lt 0 -or $idx -ge $bmList.Count) {
        Write-Host "❌ 无效选择" -ForegroundColor Red
        exit 1
    }
    $selectedBm = $bmList[$idx]
}

$bmId = $selectedBm.id
Write-Host "📌 已选择: $($selectedBm.name) (ID: $bmId)"

# ========== Step 2: 获取 BM 下像素 ==========

Write-BridgeStep "Step 2: 获取 BM ($($selectedBm.name)) 下的像素"

$pixelResult = Invoke-BridgeApi -Method GET `
    -Url "https://graph.facebook.com/$ApiVersion/$bmId/owned_pixels?fields=id,name,code,creation_time,last_fired_time" `
    -Description "获取 BM $bmId 的像素列表"

$pixelList = @()
if ($pixelResult.Success -and $pixelResult.Data.data) {
    $pixelList = $pixelResult.Data.data
    Write-Host "✅ 找到 $($pixelList.Count) 个像素:" -ForegroundColor Green
    for ($i = 0; $i -lt $pixelList.Count; $i++) {
        $px = $pixelList[$i]
        $lastFired = if ($px.last_fired_time) { "最后触发: $($px.last_fired_time)" } else { "未触发" }
        Write-Host "   $($i+1). $($px.name) (ID: $($px.id)) | Code: $($px.code) | $lastFired"
    }
} else {
    Write-Host "❌ 无法获取像素列表!" -ForegroundColor Red
    Write-Host "   该 BM 可能没有像素，或 Token 权限不足"
    if ($pixelResult.Data) {
        Write-Host "   API 响应: $($pixelResult.Data | ConvertTo-Json -Depth 3)"
    }
    exit 1
}

if ($pixelList.Count -eq 0) {
    Write-Host "⚠️ 该 BM 下没有像素，无需分享" -ForegroundColor Yellow
    exit 0
}

# 选择像素
$choice = Read-Host "`n选择要分享的像素 (输入编号)"
$idx = [int]$choice - 1
if ($idx -lt 0 -or $idx -ge $pixelList.Count) {
    Write-Host "❌ 无效选择" -ForegroundColor Red
    exit 1
}
$selectedPixel = $pixelList[$idx]
Write-Host "📌 已选择像素: $($selectedPixel.name) (ID: $($selectedPixel.id))"

# ========== Step 3: 分享像素到合作伙伴 ==========

Write-BridgeStep "Step 3: 分享像素到合作伙伴 BM"

$partnerBmId = Read-Host "输入合作伙伴的 Business Manager ID"
if (-not $partnerBmId) {
    Write-Host "❌ 合作伙伴 BM ID 不能为空" -ForegroundColor Red
    exit 1
}

$shareBody = @{
    business = $partnerBmId
}

Write-Host "`n📤 分享像素:" -ForegroundColor Cyan
Write-Host "   像素: $($selectedPixel.name) (ID: $($selectedPixel.id))"
Write-Host "   来自: $($selectedBm.name) (BM ID: $bmId)"
Write-Host "   目标: BM ID: $partnerBmId"

$confirm = Read-Host "`n确认分享? (y/N)"
if ($confirm -notmatch '^[yY]') {
    Write-Host "已取消" -ForegroundColor Yellow
    exit 0
}

$shareResult = Invoke-BridgeApi -Method POST `
    -Url "https://graph.facebook.com/$ApiVersion/$($selectedPixel.id)/shared_agencies" `
    -Body $shareBody `
    -Description "分享像素 $($selectedPixel.id) → BM $partnerBmId"

if ($shareResult.Success) {
    Write-Host "`n🎉 像素分享成功!" -ForegroundColor Green
    Write-Host "   合作伙伴 BM $partnerBmId 现在可以访问像素 $($selectedPixel.name)"
} else {
    Write-Host "`n❌ 像素分享失败" -ForegroundColor Red
    if ($shareResult.Error) {
        $errStr = if ($shareResult.Error -is [string]) { $shareResult.Error } else { $shareResult.Error | ConvertTo-Json -Depth 3 }
        Write-Host "   错误: $errStr"

        # 常见错误提示
        if ($errStr -match "permission|权限") {
            Write-Host "   💡 请确认 Token 有 business_management 权限" -ForegroundColor Yellow
        } elseif ($errStr -match "not found|不存在") {
            Write-Host "   💡 请检查合作伙伴 BM ID 是否正确" -ForegroundColor Yellow
        } elseif ($errStr -match "already|已分享") {
            Write-Host "   💡 该像素可能已经分享给此 BM" -ForegroundColor Yellow
        }
    }
}
