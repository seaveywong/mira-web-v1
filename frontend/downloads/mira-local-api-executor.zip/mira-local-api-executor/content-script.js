/**
 * Mira 本地 API 执行器 - Content Script
 * 注入到 Facebook 页面，自动提取 Access Token（EAA Token）
 * 参考 FB Token Extractor 插件的提取逻辑
 */

// ========== 从 localStorage 提取 EAA Token ==========

function extractFromLocalStorage() {
  const result = { eaa_token: null, eaa_key: null };
  try {
    // 先检查已知的 key
    const knownKeys = [
      'EAA_token',
      'fb_access_token',
      'access_token',
      'fb_messenger_access_token',
    ];
    for (const key of knownKeys) {
      const val = localStorage.getItem(key);
      if (val && val.startsWith('EAA')) {
        result.eaa_token = val;
        result.eaa_key = key;
        return result;
      }
    }
    // 遍历所有 key 查找 EAA token
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      try {
        const val = localStorage.getItem(key);
        if (val && typeof val === 'string' && val.startsWith('EAA')) {
          result.eaa_token = val;
          result.eaa_key = key;
          break;
        }
      } catch (e) { /* 某些 key 可能无法访问 */ }
    }
  } catch (e) {
    result._error = e.message;
  }
  return result;
}

// ========== 从 sessionStorage 提取 ==========

function extractFromSessionStorage() {
  const result = { eaa_token: null, eaa_key: null };
  try {
    for (let i = 0; i < sessionStorage.length; i++) {
      const key = sessionStorage.key(i);
      try {
        const val = sessionStorage.getItem(key);
        if (val && typeof val === 'string' && val.startsWith('EAA')) {
          result.eaa_token = val;
          result.eaa_key = key;
          break;
        }
      } catch (e) { /* ignore */ }
    }
  } catch (e) {
    result._error = e.message;
  }
  return result;
}

// ========== 从页面 JS 全局变量提取 ==========

function extractFromPageJS() {
  const result = {};

  // 1. EAA Token 从 window 变量
  try {
    const windowTokenKeys = [
      '___fbAccessToken',
      '__fbAccessToken',
      'fbAccessToken',
      '_fbToken',
      '__fb_token',
    ];
    for (const key of windowTokenKeys) {
      try {
        const val = window[key];
        if (val && typeof val === 'string' && val.startsWith('EAA')) {
          result.eaa_token = val;
          result.eaa_source = `window.${key}`;
          break;
        }
      } catch (e) { /* ignore */ }
    }
  } catch (e) { /* ignore */ }

  // 2. fb_dtsg (CSRF token)
  try {
    if (typeof DTSG_INIT_VAL !== 'undefined' && DTSG_INIT_VAL) {
      result.fb_dtsg = String(DTSG_INIT_VAL);
    }
    if (typeof DTSGInitialData !== 'undefined' && DTSGInitialData) {
      if (DTSGInitialData.token) result.fb_dtsg = result.fb_dtsg || String(DTSGInitialData.token);
    }
    if (typeof window.fb_dtsg !== 'undefined' && window.fb_dtsg) {
      result.fb_dtsg = result.fb_dtsg || String(window.fb_dtsg);
    }
  } catch (e) { /* ignore */ }

  // 3. 从页面内嵌 script 标签搜索 EAA token
  if (!result.eaa_token) {
    try {
      const scripts = document.querySelectorAll('script');
      for (const script of scripts) {
        if (script.textContent && script.textContent.includes('EAA')) {
          const match = script.textContent.match(/EAA\w{50,}/);
          if (match) {
            result.eaa_token = match[0];
            result.eaa_source = 'inline_script';
            break;
          }
        }
      }
    } catch (e) { /* ignore */ }
  }

  return result;
}

// ========== 综合提取 ==========

function extractAllTokens() {
  const lsResult = extractFromLocalStorage();
  const ssResult = extractFromSessionStorage();
  const pageResult = extractFromPageJS();

  // 优先级：localStorage > sessionStorage > 页面 JS
  const eaa_token = lsResult.eaa_token || ssResult.eaa_token || pageResult.eaa_token || null;
  let eaa_source = '';
  if (lsResult.eaa_token) eaa_source = `localStorage:${lsResult.eaa_key}`;
  else if (ssResult.eaa_token) eaa_source = `sessionStorage:${ssResult.eaa_key}`;
  else if (pageResult.eaa_token) eaa_source = pageResult.eaa_source || 'page_js';

  return {
    eaa_token,
    eaa_source,
    fb_dtsg: pageResult.fb_dtsg || null,
    _details: {
      localStorage: lsResult,
      sessionStorage: ssResult,
      page: pageResult,
    },
  };
}

// ========== 消息监听 ==========

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'extractFacebookToken') {
    const tokens = extractAllTokens();
    sendResponse(tokens);
    return true;
  }
});

// ========== 页面加载后自动尝试提取并缓存（带延迟重试） ==========

(function autoCacheOnLoad() {
  // 第一次尝试
  tryCacheToken();

  // SPA 页面（如 adsmanager）可能需要更长时间初始化
  // 在 3 秒和 8 秒后重试
  setTimeout(tryCacheToken, 3000);
  setTimeout(tryCacheToken, 8000);

  function tryCacheToken() {
    try {
      const extracted = extractAllTokens();
      if (extracted.eaa_token) {
        chrome.runtime.sendMessage({
          type: 'facebookTokenCache',
          payload: {
            eaa_token: extracted.eaa_token,
            eaa_source: extracted.eaa_source,
            fb_dtsg: extracted.fb_dtsg,
            url: location.href,
            timestamp: new Date().toISOString(),
          },
        }).catch(() => { /* background 可能未就绪 */ });
      }
    } catch (e) { /* ignore */ }
  }
})();
