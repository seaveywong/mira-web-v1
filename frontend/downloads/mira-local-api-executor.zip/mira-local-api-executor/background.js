/**
 * Mira 本地 API 执行器 v1.5 — Service Worker
 *
 * 功能:
 *   1. 自动静默提取 Facebook Access Token（无需手动操作）
 *   2. 每 ~55 分钟自动静默刷新 Token
 *   3. Mira 远程任务心跳 + 轮询 + Graph API 执行
 *   4. 像素分享、BM 用户邀请等 Graph API 调用
 */

const DEFAULT_SERVER_URL = "https://shouhu.asia";
const HEARTBEAT_ALARM = "mira_local_api_executor_heartbeat";
const EXECUTOR_ALARM = "mira_local_api_executor_poll";
const TOKEN_REFRESH_ALARM = "mira_local_api_executor_token_refresh";
const AUTO_REFRESH_MINUTES = 55;
const GRAPH_BASE = "https://graph.facebook.com/v25.0";

const runningTasks = new Set();
let lastProbeAt = 0;
let lastProbeSummary = null;
let lastTokenExtractAt = 0;
let cachedExtractedToken = null;

const FB_COOKIE_NAMES = ['c_user', 'xs', 'fr', 'datr', 'sb'];

// ========== 工具函数 ==========

function normalizeServerUrl(value) {
  const raw = String(value || DEFAULT_SERVER_URL).trim().replace(/\/+$/, "");
  return raw || DEFAULT_SERVER_URL;
}

function randomId(prefix) {
  const bytes = new Uint8Array(8);
  crypto.getRandomValues(bytes);
  return `${prefix}_${Array.from(bytes).map((b) => b.toString(16).padStart(2, "0")).join("")}`;
}

function maskToken(token) {
  const raw = String(token || "").trim();
  if (!raw) return "";
  if (raw.length <= 12) return "****";
  return `${raw.slice(0, 6)}****${raw.slice(-4)}`;
}

function elapsed(ts) {
  if (!ts) return "--";
  const s = Math.round((Date.now() - new Date(ts).getTime()) / 1000);
  if (s < 60) return `${s}秒前`;
  if (s < 3600) return `${Math.round(s / 60)}分钟前`;
  return `${Math.round(s / 3600)}小时前`;
}

// ========== 安装 & 启动 ==========

async function ensureInstallId() {
  const data = await chrome.storage.local.get(["installId"]);
  if (data.installId) return data.installId;
  const installId = randomId("chrome");
  await chrome.storage.local.set({ installId });
  return installId;
}

async function detectChromeName() {
  const installId = await ensureInstallId();
  return `Chrome-${installId.slice(-6).toUpperCase()}`;
}

// ========== 结构化状态（供 popup 仪表盘读取） ==========

async function getFullStatus() {
  const s = await getSettings();
  const cookies = await getFacebookCookies();
  const data = await chrome.storage.local.get([
    'tokenStatus', 'lastStatus', 'autoRefreshToken'
  ]);
  return {
    settings: s,
    cookies: { c_user: cookies.c_user || null, xs: cookies.xs ? '****' : null },
    tokenStatus: data.tokenStatus || null,
    miraStatus: data.lastStatus || null,
    autoRefresh: true,
  };
}

async function updateTokenStatus(status) {
  await chrome.storage.local.set({ tokenStatus: { ...status, updatedAt: new Date().toISOString() } });
}

// ========== Facebook Token 自动提取 ==========

async function getFacebookCookies() {
  const result = {};
  for (const name of FB_COOKIE_NAMES) {
    try {
      const cookie = await chrome.cookies.get({ url: 'https://www.facebook.com', name });
      if (cookie) result[name] = cookie.value;
    } catch (e) { /* Cookie 不存在或无权限 */ }
  }
  return result;
}

function waitForTabComplete(tabId, timeoutMs = 20000) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(listener);
      reject(new Error('页面加载超时'));
    }, timeoutMs);
    chrome.tabs.onUpdated.addListener(function listener(tid, changeInfo) {
      if (tid === tabId && changeInfo.status === 'complete') {
        clearTimeout(timer);
        chrome.tabs.onUpdated.removeListener(listener);
        resolve();
      }
    });
  });
}

async function extractFromTab(tabId) {
  try {
    return await chrome.tabs.sendMessage(tabId, { action: 'extractFacebookToken' });
  } catch (e) {
    try {
      await chrome.scripting.executeScript({ target: { tabId }, files: ['content-script.js'] });
    } catch (e2) { /* ignore */ }
    await new Promise(r => setTimeout(r, 500));
    return await chrome.tabs.sendMessage(tabId, { action: 'extractFacebookToken' });
  }
}

async function extractFacebookTokenFromTabs() {
  // ===== 第一步：尝试已有 Facebook 标签页 =====
  const existingTabs = await chrome.tabs.query({ url: '*://*.facebook.com/*' });
  for (const tab of existingTabs) {
    try {
      const pageTokens = await extractFromTab(tab.id);
      if (pageTokens && pageTokens.eaa_token) {
        const cookies = await getFacebookCookies();
        const result = {
          eaa_token: pageTokens.eaa_token,
          eaa_source: pageTokens.eaa_source || `已有标签页: ${tab.url}`,
          fb_dtsg: pageTokens.fb_dtsg || null,
          c_user: cookies.c_user || null,
          xs: cookies.xs || null,
          cookies,
          extracted_at: new Date().toISOString(),
          from_tab: tab.url || ''
        };
        lastTokenExtractAt = Date.now();
        cachedExtractedToken = result;
        return result;
      }
    } catch (e) { /* 该标签页不可用 */ }
  }

  // ===== 第二步：静默打开 adsmanager =====
  console.debug('[mira] 静默打开 adsmanager.facebook.com 提取 Token...');
  let newTab = null;
  try {
    newTab = await chrome.tabs.create({
      url: 'https://adsmanager.facebook.com/',
      active: false
    });

    await waitForTabComplete(newTab.id, 25000);
    await new Promise(r => setTimeout(r, 5000)); // 等 SPA 初始化

    const pageTokens = await extractFromTab(newTab.id);
    try { await chrome.tabs.remove(newTab.id); } catch (e) { /* ignore */ }

    const cookies = await getFacebookCookies();

    if (pageTokens && pageTokens.eaa_token) {
      const result = {
        eaa_token: pageTokens.eaa_token,
        eaa_source: pageTokens.eaa_source || 'adsmanager (静默打开)',
        fb_dtsg: pageTokens.fb_dtsg || null,
        c_user: cookies.c_user || null,
        xs: cookies.xs || null,
        cookies,
        extracted_at: new Date().toISOString(),
        from_tab: 'https://adsmanager.facebook.com/ (静默)'
      };
      lastTokenExtractAt = Date.now();
      cachedExtractedToken = result;
      return result;
    }
    throw new Error('adsmanager 页面加载完成但未找到 EAA Token，请确认 Chrome 已登录 Facebook');
  } catch (err) {
    if (newTab) {
      try { await chrome.tabs.remove(newTab.id); } catch (e) { /* ignore */ }
    }
    throw err;
  }
}

async function silentExtractAndSave() {
  console.debug('[mira] 开始静默提取 Token...');
  try {
    const extracted = await extractFacebookTokenFromTabs();
    if (extracted.eaa_token) {
      const expiresAt = new Date(Date.now() + AUTO_REFRESH_MINUTES * 60000).toISOString();
      await chrome.storage.local.set({
        accessToken: extracted.eaa_token,
        expiresInMinutes: String(AUTO_REFRESH_MINUTES),
        tokenExpiresAt: expiresAt
      });
      lastProbeAt = 0;
      lastProbeSummary = null;

      await updateTokenStatus({
        valid: true,
        tokenMask: maskToken(extracted.eaa_token),
        source: extracted.eaa_source || '自动提取',
        extractedAt: extracted.extracted_at,
        expiresAt,
        c_user: extracted.c_user,
        error: null
      });

      // 验证 Token 并更新用户信息
      verifyAndUpdateTokenInfo(extracted.eaa_token).catch(() => {});

      // Token 变化时立刻重新心跳，确保 Mira 及时获知新 Token
      heartbeat(true).catch(() => {});

      console.debug('[mira] Token 静默提取成功:', maskToken(extracted.eaa_token));
      return extracted;
    }
    throw new Error('未找到可用 Token');
  } catch (err) {
    console.debug('[mira] 静默提取失败:', err.message);
    await updateTokenStatus({
      valid: false,
      tokenMask: null,
      source: null,
      extractedAt: null,
      expiresAt: null,
      c_user: null,
      error: err.message
    });
    return null;
  }
}

async function verifyAndUpdateTokenInfo(token) {
  try {
    const me = await graphGetRaw(token, "me", { fields: "id,name" });
    const perms = await graphGetRaw(token, "me/permissions", {});
    const granted = (perms.data || [])
      .filter(p => String(p.status || "").toLowerCase() === "granted")
      .map(p => p.permission);

    await updateTokenStatus({
      valid: true,
      tokenMask: maskToken(token),
      fbName: me.name || "",
      fbId: me.id || "",
      permissions: granted,
      hasAdsMgmt: granted.includes('ads_management'),
      hasBizMgmt: granted.includes('business_management'),
      error: null
    });
  } catch (err) {
    await updateTokenStatus({
      valid: false,
      tokenMask: maskToken(token),
      error: `Token 验证失败: ${err.message}`
    });
  }
}

async function graphGetRaw(token, path, params = {}) {
  const cleanPath = String(path || "").replace(/^\/+/, "");
  const url = new URL(`${GRAPH_BASE}/${cleanPath}`);
  Object.entries(params || {}).forEach(([key, value]) => {
    if (value !== undefined && value !== null && value !== "") {
      url.searchParams.set(key, String(value));
    }
  });
  url.searchParams.set("access_token", token);
  const res = await fetch(url.toString());
  const data = await res.json().catch(() => ({}));
  if (!res.ok || data.error) throw new Error(data.error?.message || `HTTP ${res.status}`);
  return data;
}

// ========== Settings ==========

async function getSettings() {
  const data = await chrome.storage.local.get([
    "serverUrl", "nodeName", "nodeId", "nodeSecret",
    "accessToken", "expiresInMinutes", "tokenExpiresAt", "lastStatus"
  ]);
  return {
    serverUrl: normalizeServerUrl(data.serverUrl),
    nodeName: data.nodeName || await detectChromeName(),
    nodeId: data.nodeId || "",
    nodeSecret: data.nodeSecret || "",
    accessToken: data.accessToken || "",
    expiresInMinutes: data.expiresInMinutes || "",
    tokenExpiresAt: data.tokenExpiresAt || "",
    lastStatus: data.lastStatus || null
  };
}

// ========== Mira 通信 ==========

async function postJson(serverUrl, path, body) {
  const res = await fetch(normalizeServerUrl(serverUrl) + path, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body || {})
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.detail || data.message || `HTTP ${res.status}`);
  return data;
}

async function graphRequest(method, path, params = {}) {
  const s = await getSettings();
  const token = String(s.accessToken || "").trim();
  if (!token) throw new Error("本地执行器未配置 Graph API Token");
  const cleanPath = String(path || "").replace(/^\/+/, "");
  const url = new URL(`${GRAPH_BASE}/${cleanPath}`);
  const body = new URLSearchParams();
  Object.entries(params || {}).forEach(([key, value]) => {
    if (value !== undefined && value !== null && value !== "") {
      if (method === "GET") url.searchParams.set(key, String(value));
      else body.set(key, String(value));
    }
  });
  if (method === "GET") url.searchParams.set("access_token", token);
  else body.set("access_token", token);
  const res = await fetch(url.toString(), {
    method,
    headers: method === "GET" ? undefined : { "Content-Type": "application/x-www-form-urlencoded" },
    body: method === "GET" ? undefined : body.toString()
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok || data.error) {
    const err = data.error || {};
    const code = err.code ? `code=${err.code}` : "";
    const sub = err.error_subcode || err.subcode ? `subcode=${err.error_subcode || err.subcode}` : "";
    const detail = [err.message || `HTTP ${res.status}`, code, sub].filter(Boolean).join(" | ");
    throw new Error(detail);
  }
  return data;
}

async function graphGet(path, params = {}) {
  return graphRequest("GET", path, params);
}

async function graphPost(path, params = {}) {
  return graphRequest("POST", path, params);
}

function normalizeActId(value) {
  const raw = String(value || "").trim();
  if (!raw) return "";
  return raw.startsWith("act_") ? raw : `act_${raw}`;
}

async function fetchAllAdAccounts() {
  const out = [];
  let path = "me/adaccounts";
  let params = { fields: "id,name,account_status", limit: 200 };
  for (let i = 0; i < 20; i += 1) {
    const data = await graphGet(path, params);
    (data.data || []).forEach((item) => {
      const actId = normalizeActId(item.id);
      if (actId) out.push(actId);
    });
    const next = data.paging && data.paging.next;
    if (!next) break;
    const nextUrl = new URL(next);
    path = nextUrl.pathname.replace(/^\/v[0-9.]+\//, "");
    params = Object.fromEntries(nextUrl.searchParams.entries());
    delete params.access_token;
  }
  return Array.from(new Set(out));
}

async function buildTokenSummary(force = false) {
  const s = await getSettings();
  const token = String(s.accessToken || "").trim();
  if (!token) {
    lastProbeSummary = null;
    return { present: false };
  }
  if (!force && lastProbeSummary && Date.now() - lastProbeAt < 5 * 60 * 1000) {
    return lastProbeSummary;
  }
  const summary = {
    present: true,
    token_mask: maskToken(token),
    token_expires_at: s.tokenExpiresAt || "",
    fb_user_id: "",
    fb_user_name: "",
    permissions: { granted: [], declined: [] },
    account_ids: [],
    has_ads_management: false,
    has_ads_read: false,
    last_error: ""
  };
  try {
    const me = await graphGet("me", { fields: "id,name" });
    summary.fb_user_id = String(me.id || "");
    summary.fb_user_name = String(me.name || "");
    try {
      const perms = await graphGet("me/permissions", {});
      const granted = [];
      const declined = [];
      (perms.data || []).forEach((item) => {
        const name = String(item.permission || "").trim();
        if (!name) return;
        if (String(item.status || "").toLowerCase() === "granted") granted.push(name);
        else declined.push(name);
      });
      summary.permissions = {
        granted: Array.from(new Set(granted)).sort(),
        declined: Array.from(new Set(declined)).sort()
      };
      summary.has_ads_management = summary.permissions.granted.includes("ads_management");
      summary.has_ads_read = summary.permissions.granted.includes("ads_read") || summary.has_ads_management;
    } catch (err) {
      summary.last_error = `权限读取失败：${err.message || err}`;
    }
    try {
      summary.account_ids = await fetchAllAdAccounts();
    } catch (err) {
      summary.last_error = summary.last_error || `账户读取失败：${err.message || err}`;
    }
  } catch (err) {
    summary.last_error = err.message || String(err);
  }
  lastProbeAt = Date.now();
  lastProbeSummary = summary;
  return summary;
}

// ========== Mira 任务执行 ==========

async function updateExecutorTask(task, status, progress, result = {}, error = "") {
  const s = await getSettings();
  if (!task || !task.id || !s.nodeId || !s.nodeSecret) return null;
  return postJson(s.serverUrl, `/api/local-executor/tasks/${encodeURIComponent(task.id)}/update`, {
    node_id: s.nodeId,
    node_secret: s.nodeSecret,
    status, progress, result, error,
    screenshot_data_url: ""
  });
}

async function executeAccountProbe(task) {
  const params = task.params || {};
  const actId = normalizeActId(params.act_id || task.account_id);
  if (!actId) throw new Error("任务缺少广告账户 ID");
  await updateExecutorTask(task, "running", "正在用本地 Graph API 读取账户");
  const account = await graphGet(actId, {
    fields: params.fields || "id,name,account_status,currency,timezone_name,amount_spent,spend_cap,balance"
  });
  const summary = await buildTokenSummary(true);
  await updateExecutorTask(task, "success", "账户 API 自检完成", {
    account,
    token_user: {
      id: summary.fb_user_id, name: summary.fb_user_name,
      has_ads_management: summary.has_ads_management,
      has_ads_read: summary.has_ads_read
    }
  });
}

async function executeUpdateStatus(task) {
  const params = task.params || {};
  const objectId = String(params.object_id || "").trim();
  const status = String(params.status || "PAUSED").trim().toUpperCase();
  const level = String(params.level || "").trim().toLowerCase();
  if (!objectId) throw new Error("任务缺少广告/广告组/系列 ID");
  if (!["ACTIVE", "PAUSED"].includes(status)) throw new Error("状态只支持 ACTIVE 或 PAUSED");
  await updateExecutorTask(task, "running", `正在将 ${level || "object"} ${objectId} 更新为 ${status}`);
  const result = await graphPost(objectId, { status });
  await updateExecutorTask(task, "success", `状态已更新为 ${status}`, {
    object_id: objectId, status, level, graph_result: result
  });
}

async function executeTask(task) {
  if (!task || !task.id || runningTasks.has(task.id)) return;
  runningTasks.add(task.id);
  try {
    const s = await getSettings();
    if (!String(s.accessToken || "").trim()) {
      await updateExecutorTask(task, "need_user", "本地执行器没有可用 API Token，正在尝试自动提取...", {}, "Token 缺失");
      // 尝试自动提取并重试
      await silentExtractAndSave();
      const s2 = await getSettings();
      if (!String(s2.accessToken || "").trim()) {
        await updateExecutorTask(task, "need_user", "请确保 Chrome 已登录 Facebook", {}, "自动提取 Token 失败");
        return;
      }
    }
    if (task.task_type === "graph_account_probe") { await executeAccountProbe(task); return; }
    if (task.task_type === "graph_update_status") { await executeUpdateStatus(task); return; }
    await updateExecutorTask(task, "failed", "插件不支持此任务类型", {}, `Unsupported: ${task.task_type}`);
  } catch (err) {
    await updateExecutorTask(task, "failed", "本地 API 执行失败", {}, err.message || String(err));
  } finally {
    runningTasks.delete(task.id);
  }
}

async function pollExecutorTask() {
  const s = await getSettings();
  if (!s.nodeId || !s.nodeSecret || runningTasks.size > 0) return null;
  const data = await postJson(s.serverUrl, "/api/local-executor/poll", {
    node_id: s.nodeId,
    node_secret: s.nodeSecret
  });
  if (data && data.task) {
    executeTask(data.task).catch(() => {});
  }
  return data;
}

async function registerNode(payload) {
  const serverUrl = normalizeServerUrl(payload.serverUrl);
  const nodeName = payload.nodeName || await detectChromeName();
  const data = await postJson(serverUrl, "/api/local-tokens/register", {
    code: payload.code,
    node_name: nodeName,
    browser: "Chrome",
    user_agent: navigator.userAgent
  });
  await chrome.storage.local.set({
    serverUrl,
    nodeName: payload.nodeName || data.node_name || nodeName,
    nodeId: data.node_id,
    nodeSecret: data.node_secret,
    lastStatus: {
      ok: true,
      message: "执行器绑定成功",
      updatedAt: new Date().toLocaleString()
    }
  });
  await ensureAlarm();
  return data;
}

async function heartbeat(forceProbe = false) {
  const s = await getSettings();
  if (!s.nodeId || !s.nodeSecret) {
    return { ok: false, message: "插件尚未绑定 Mira" };
  }
  const tokenSummary = await buildTokenSummary(forceProbe);
  const data = await postJson(s.serverUrl, "/api/local-tokens/heartbeat", {
    node_id: s.nodeId,
    node_secret: s.nodeSecret,
    access_token: s.accessToken || "",
    expires_at: s.tokenExpiresAt || "",
    expires_in_minutes: null,
    token_summary: tokenSummary,
    node_name: s.nodeName || await detectChromeName(),
    browser: "Chrome",
    user_agent: navigator.userAgent
  });
  const status = {
    ok: true,
    message: data.node && data.node.status ? `心跳成功：${data.node.status}` : "心跳成功",
    updatedAt: new Date().toLocaleString(),
    node: data.node || null
  };
  await chrome.storage.local.set({ lastStatus: status });
  return status;
}

// ========== 告警管理 ==========

async function ensureAlarm() {
  // Mira 心跳 + 任务轮询
  await chrome.alarms.clear(HEARTBEAT_ALARM);
  await chrome.alarms.create(HEARTBEAT_ALARM, { periodInMinutes: 0.5 });
  await chrome.alarms.clear(EXECUTOR_ALARM);
  await chrome.alarms.create(EXECUTOR_ALARM, { periodInMinutes: 0.5 });
  // Token 自动刷新 (始终开启)
  await chrome.alarms.clear(TOKEN_REFRESH_ALARM);
  await chrome.alarms.create(TOKEN_REFRESH_ALARM, { periodInMinutes: AUTO_REFRESH_MINUTES });
}

// ========== 初始化：自动提取 Token ==========

async function initialAutoExtract() {
  const s = await getSettings();
  // 延迟几秒等 Chrome 完全启动
  await new Promise(r => setTimeout(r, 3000));

  // 检查是否需要提取
  let needExtract = !s.accessToken;
  if (s.accessToken && s.tokenExpiresAt) {
    const remaining = new Date(s.tokenExpiresAt).getTime() - Date.now();
    if (remaining < 10 * 60 * 1000) needExtract = true; // 少于 10 分钟就刷新
  }

  if (needExtract) {
    console.debug('[mira] 启动时自动提取 Token...');
    await silentExtractAndSave();
  } else if (s.accessToken) {
    // 更新状态
    await updateTokenStatus({
      valid: true,
      tokenMask: maskToken(s.accessToken),
      extractedAt: s.tokenExpiresAt
        ? new Date(new Date(s.tokenExpiresAt).getTime() - AUTO_REFRESH_MINUTES * 60000).toISOString()
        : null,
      expiresAt: s.tokenExpiresAt,
      error: null
    });
    verifyAndUpdateTokenInfo(s.accessToken).catch(() => {});
  }
}

// ========== 事件监听 ==========

chrome.runtime.onInstalled.addListener(() => {
  ensureAlarm().catch(() => {});
  // 安装后延迟自动提取
  setTimeout(() => { initialAutoExtract().catch(() => {}); }, 5000);
});

// Service Worker 启动时自动提取
initialAutoExtract().catch(() => {});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === TOKEN_REFRESH_ALARM) {
    silentExtractAndSave().catch(() => {});
    return;
  }
  if (alarm.name === EXECUTOR_ALARM) {
    pollExecutorTask().catch(async (err) => {
      await chrome.storage.local.set({
        lastStatus: {
          ok: false,
          message: err.message || String(err),
          updatedAt: new Date().toLocaleString()
        }
      });
    });
    return;
  }
  if (alarm.name !== HEARTBEAT_ALARM) return;
  heartbeat(false).catch(async (err) => {
    await chrome.storage.local.set({
      lastStatus: {
        ok: false,
        message: err.message || String(err),
        updatedAt: new Date().toLocaleString()
      }
    });
  });
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  (async () => {
    if (message.type === "getSettings") {
      sendResponse({ ok: true, data: await getSettings() });
      return;
    }
    if (message.type === "getFullStatus") {
      sendResponse({ ok: true, data: await getFullStatus() });
      return;
    }
    if (message.type === "saveSettings") {
      const old = await getSettings();
      const nextToken = message.accessToken || "";
      const nextMinutes = message.expiresInMinutes || "";
      let tokenExpiresAt = old.tokenExpiresAt || "";
      if (nextToken !== old.accessToken || nextMinutes !== old.expiresInMinutes) {
        const parsedMinutes = parseInt(nextMinutes || "0", 10);
        tokenExpiresAt = nextToken && Number.isFinite(parsedMinutes) && parsedMinutes > 0
          ? new Date(Date.now() + parsedMinutes * 60000).toISOString()
          : "";
        lastProbeAt = 0;
        lastProbeSummary = null;
      }
      await chrome.storage.local.set({
        serverUrl: normalizeServerUrl(message.serverUrl),
        nodeName: message.nodeName || await detectChromeName(),
        accessToken: nextToken,
        expiresInMinutes: nextMinutes,
        tokenExpiresAt
      });
      await ensureAlarm();
      sendResponse({ ok: true, data: await getSettings() });
      return;
    }
    if (message.type === "register") {
      sendResponse({ ok: true, data: await registerNode(message) });
      return;
    }
    if (message.type === "heartbeat") {
      sendResponse({ ok: true, data: await heartbeat(true) });
      return;
    }
    if (message.type === "pollTask") {
      sendResponse({ ok: true, data: await pollExecutorTask() });
      return;
    }
    if (message.type === "clearToken") {
      lastProbeAt = 0;
      lastProbeSummary = null;
      await chrome.storage.local.set({ accessToken: "", expiresInMinutes: "", tokenExpiresAt: "" });
      await updateTokenStatus({ valid: false, tokenMask: null, error: "用户手动清除" });
      sendResponse({ ok: true, data: await heartbeat(true).catch((err) => ({ ok: false, message: err.message })) });
      return;
    }
    if (message.type === "extractFacebookToken") {
      try {
        const extracted = await extractFacebookTokenFromTabs();
        if (extracted.eaa_token) {
          const expiresAt = new Date(Date.now() + AUTO_REFRESH_MINUTES * 60000).toISOString();
          await chrome.storage.local.set({
            accessToken: extracted.eaa_token,
            expiresInMinutes: String(AUTO_REFRESH_MINUTES),
            tokenExpiresAt: expiresAt
          });
          lastProbeAt = 0;
          lastProbeSummary = null;
          await updateTokenStatus({
            valid: true,
            tokenMask: maskToken(extracted.eaa_token),
            source: extracted.eaa_source,
            extractedAt: extracted.extracted_at,
            expiresAt,
            c_user: extracted.c_user,
            error: null
          });
          verifyAndUpdateTokenInfo(extracted.eaa_token).catch(() => {});
          heartbeat(true).catch(() => {});
        }
        sendResponse({ ok: true, data: { ...extracted, saved: !!extracted.eaa_token } });
      } catch (err) {
        sendResponse({ ok: false, error: err.message || String(err) });
      }
      return;
    }
    if (message.type === "silentRefresh") {
      const result = await silentExtractAndSave();
      heartbeat(true).catch(() => {});
      sendResponse({ ok: true, data: { success: !!result, tokenMask: result ? maskToken(result.eaa_token) : null } });
      return;
    }
    if (message.type === "facebookTokenCache") {
      const payload = message.payload || {};
      if (payload.eaa_token && (!cachedExtractedToken || payload.eaa_token !== cachedExtractedToken.eaa_token)) {
        cachedExtractedToken = payload;
        lastTokenExtractAt = Date.now();
        // 检查是否需要更新存储的 Token
        const data = await chrome.storage.local.get(['accessToken']);
        if (payload.eaa_token !== data.accessToken) {
          const expiresAt = new Date(Date.now() + AUTO_REFRESH_MINUTES * 60000).toISOString();
          await chrome.storage.local.set({
            accessToken: payload.eaa_token,
            expiresInMinutes: String(AUTO_REFRESH_MINUTES),
            tokenExpiresAt: expiresAt
          });
          lastProbeAt = 0;
          lastProbeSummary = null;
          // Token 变化时立刻心跳
          heartbeat(true).catch(() => {});
        }
      }
      sendResponse({ ok: true });
      return;
    }
    // ===== 通用 Graph API 调用 =====
    if (message.type === "graphApiCall") {
      try {
        const method = (message.method || "GET").toUpperCase();
        const path = message.path || "";
        const params = message.params || {};
        let data;
        if (method === "GET") {
          data = await graphGet(path, params);
        } else {
          data = await graphPost(path, params);
        }
        sendResponse({ ok: true, data });
      } catch (err) {
        sendResponse({ ok: false, error: err.message || String(err) });
      }
      return;
    }
    sendResponse({ ok: false, error: "unknown message" });
  })().catch((err) => {
    sendResponse({ ok: false, error: err.message || String(err) });
  });
  return true;
});
