Mira 本地执行器 v1.5.0

═══════════════════════════════════════
  全自动 Token 提取 + 内置工具集
═══════════════════════════════════════

安装：
1. 打开 chrome://extensions → 开启"开发者模式"
2. "加载已解压的扩展程序" → 选择本文件夹
3. 在 Chrome 中打开 facebook.com 并登录
4. 插件自动静默提取 Token — 无需任何手动操作！

4 个标签页：

  📊 状态 — Token 有效期/用户/权限/来源 + Mira 连接心跳
  📤 像素分享 — BM列表 → 选择像素 → 输入合作伙伴BM → 一键分享
  👥 BM邀请 — 选择BM → 输入邮箱+角色 → 一键邀请
  ⚙️ 配置 — Mira 绑定码/手动Token（均可留空）

全自动运行：
  • 启动后自动静默提取 Token（无 FB 标签页时自动打开 adsmanager）
  • 每 ~55 分钟静默刷新
  • Token 仅在 Chrome 本地存储，不上传
  • 所有 Graph API 调用在浏览器本地执行（原生 IP/UA/TLS）

可选：Bridge Server（CLI 工具）
  如果要通过命令行或远程服务器调用 API：

  1. 双击 bridge-server/start.bat
  2. 使用 Python 脚本：
     python share-pixel.py
     python invite-bm-user.py
     python test-client.py call GET "https://graph.facebook.com/v18.0/me"

  注意：Bridge Server 是可选组件，插件内置的标签页已覆盖所有功能。
