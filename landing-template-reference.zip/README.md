# Landing Template Reference

This is a minimal compliant landing page package.

Rules:

- Keep `LP_PIXEL_ID` and `LP_TARGET_URL`.
- Final CTA elements use `data-lp-cta`.
- Do not hard-code Pixel IDs, final redirect links, or tracking endpoints.
- Do not include Worker files. Runtime Worker files are generated during publishing.

The public page must not include backend domains, server IPs, internal API paths, or platform branding.
