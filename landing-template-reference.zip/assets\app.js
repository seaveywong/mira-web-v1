(function () {
  function getTargetUrl() {
    return typeof window.LP_TARGET_URL === "string" ? window.LP_TARGET_URL : "";
  }

  function trackContact() {
    try {
      if (window.fbq && window.LP_PIXEL_ID) {
        window.fbq("track", "Contact");
      }
    } catch (err) {
      // Pixel errors must not block navigation.
    }
  }

  function bindCta(el) {
    var target = getTargetUrl();
    if (el.tagName && el.tagName.toLowerCase() === "a") {
      el.setAttribute("href", target || "#");
    }
    el.addEventListener("click", function (event) {
      target = getTargetUrl();
      trackContact();
      if (!target) {
        event.preventDefault();
        return;
      }
      if (!el.tagName || el.tagName.toLowerCase() !== "a") {
        window.location.href = target;
      }
    });
  }

  document.addEventListener("DOMContentLoaded", function () {
    document.querySelectorAll("[data-lp-cta]").forEach(bindCta);
  });
})();
